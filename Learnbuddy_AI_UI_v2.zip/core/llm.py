"""Bọc gọi OpenAI (chat + embedding) kèm chế độ ngoại tuyến để demo luồng."""

from __future__ import annotations

import json
import re
from functools import lru_cache
from typing import Any

from . import config


class LLMError(Exception):
    """Lỗi khi gọi mô hình, hiển thị được cho người dùng."""


@lru_cache(maxsize=1)
def _client():
    if config.offline_mode():
        return None
    try:
        from openai import OpenAI
    except ImportError as exc:  # pragma: no cover
        raise LLMError("Chưa cài thư viện openai. Chạy: pip install -r requirements.txt") from exc
    return OpenAI(api_key=config.OPENAI_API_KEY)


def available() -> bool:
    return not config.offline_mode()


# --------------------------------------------------------------------------- chat


def chat(
    system: str,
    user: str,
    *,
    temperature: float | None = None,
    max_tokens: int = 900,
    json_mode: bool = False,
) -> str:
    """Gọi chat completion, trả về nội dung dạng text."""
    client = _client()
    if client is None:
        raise LLMError("OFFLINE")

    kwargs: dict[str, Any] = {
        "model": config.CHAT_MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": config.LLM_TEMPERATURE if temperature is None else temperature,
        "max_tokens": max_tokens,
    }
    if json_mode:
        kwargs["response_format"] = {"type": "json_object"}

    try:
        resp = client.chat.completions.create(**kwargs)
    except Exception as exc:  # lỗi mạng / hết quota / sai model
        raise LLMError(f"Gọi mô hình thất bại: {exc}") from exc

    content = (resp.choices[0].message.content or "").strip()
    if not content:
        raise LLMError("Mô hình trả về nội dung rỗng.")
    return content


def chat_json(system: str, user: str, *, max_tokens: int = 1200) -> dict[str, Any]:
    """Như chat() nhưng ép JSON và parse sẵn."""
    raw = chat(system, user, json_mode=True, max_tokens=max_tokens, temperature=0.2)
    return parse_json(raw)


def parse_json(raw: str) -> dict[str, Any]:
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass
    match = re.search(r"\{.*\}", raw, re.S)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError as exc:
            raise LLMError("Mô hình trả về JSON không hợp lệ.") from exc
    raise LLMError("Mô hình trả về JSON không hợp lệ.")


# ---------------------------------------------------------------------- embedding


def embed(texts: list[str]) -> list[list[float]]:
    """Sinh vector nhúng theo lô. Ném LLMError nếu chưa có khoá."""
    client = _client()
    if client is None:
        raise LLMError("OFFLINE")
    if not texts:
        return []

    vectors: list[list[float]] = []
    batch_size = 64
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        try:
            resp = client.embeddings.create(model=config.EMBED_MODEL, input=batch)
        except Exception as exc:
            raise LLMError(f"Tạo embedding thất bại: {exc}") from exc
        vectors.extend(item.embedding for item in resp.data)
    return vectors
