"""Đăng ký / đăng nhập. Mật khẩu băm bằng PBKDF2-HMAC-SHA256."""

from __future__ import annotations

import hashlib
import hmac
import re
import secrets
import sqlite3
from typing import Any

from . import config
from .db import get_conn, tx

ITERATIONS = 200_000
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")
MIN_PASSWORD_LEN = 6


class AuthError(Exception):
    """Lỗi nghiệp vụ xác thực, thông điệp hiển thị thẳng cho người dùng."""


def _hash_password(password: str, salt: str) -> str:
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), ITERATIONS)
    return dk.hex()


def _row_to_user(row: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": row["id"],
        "full_name": row["full_name"],
        "email": row["email"],
        "created_at": row["created_at"],
    }


def validate_registration(full_name: str, email: str, password: str, confirm: str) -> None:
    if not full_name.strip():
        raise AuthError("Vui lòng nhập tên sinh viên.")
    if len(full_name.strip()) < 2:
        raise AuthError("Tên sinh viên quá ngắn.")
    if not EMAIL_RE.match(email.strip()):
        raise AuthError("Email không hợp lệ.")
    if len(password) < MIN_PASSWORD_LEN:
        raise AuthError(f"Mật khẩu phải có ít nhất {MIN_PASSWORD_LEN} ký tự.")
    if password != confirm:
        raise AuthError("Mật khẩu nhập lại không khớp.")


def register(full_name: str, email: str, password: str, confirm: str) -> dict[str, Any]:
    """Tạo tài khoản mới và kích hoạt ngay. Trả về thông tin user."""
    validate_registration(full_name, email, password, confirm)

    email_norm = email.strip().lower()
    salt = secrets.token_hex(16)
    pwd_hash = _hash_password(password, salt)

    try:
        with tx() as conn:
            cur = conn.execute(
                "INSERT INTO users (full_name, email, password_hash, salt, is_active) "
                "VALUES (?, ?, ?, ?, 1)",
                (full_name.strip(), email_norm, pwd_hash, salt),
            )
            user_id = cur.lastrowid
    except sqlite3.IntegrityError as exc:
        raise AuthError("Email này đã được đăng ký. Vui lòng đăng nhập.") from exc

    return {"id": user_id, "full_name": full_name.strip(), "email": email_norm}


def login(email: str, password: str) -> dict[str, Any]:
    """Xác thực, trả về user hoặc ném AuthError."""
    if not email.strip() or not password:
        raise AuthError("Vui lòng nhập đầy đủ email và mật khẩu.")

    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM users WHERE email = ?", (email.strip().lower(),)
        ).fetchone()
    finally:
        conn.close()

    if row is None:
        raise AuthError("Email hoặc mật khẩu không đúng.")
    if not row["is_active"]:
        raise AuthError("Tài khoản chưa được kích hoạt.")

    candidate = _hash_password(password, row["salt"])
    if not hmac.compare_digest(candidate, row["password_hash"]):
        raise AuthError("Email hoặc mật khẩu không đúng.")

    return _row_to_user(row)


# ------------------------------------------------------------------ giữ phiên


def create_token(user_id: int) -> str:
    """Sinh token phiên và lưu vào CSDL. Token là chuỗi ngẫu nhiên, không chứa
    thông tin gì của người dùng, có thể thu hồi và tự hết hạn."""
    token = secrets.token_urlsafe(32)
    with tx() as conn:
        conn.execute(
            "INSERT INTO auth_tokens (token, user_id, expires_at) "
            "VALUES (?, ?, datetime('now', ?))",
            (token, user_id, f"+{config.SESSION_TTL_DAYS} days"),
        )
    return token


def user_from_token(token: str) -> dict[str, Any] | None:
    """Đổi token lấy người dùng, đồng thời gia hạn phiên. None nếu sai/hết hạn."""
    if not token:
        return None
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT u.* FROM auth_tokens t JOIN users u ON u.id = t.user_id "
            "WHERE t.token = ? AND t.expires_at > datetime('now') AND u.is_active = 1",
            (token,),
        ).fetchone()
    finally:
        conn.close()
    if row is None:
        return None

    with tx() as conn:  # gia hạn trượt theo lần dùng gần nhất
        conn.execute(
            "UPDATE auth_tokens SET expires_at = datetime('now', ?) WHERE token = ?",
            (f"+{config.SESSION_TTL_DAYS} days", token),
        )
    return _row_to_user(row)


def revoke_token(token: str) -> None:
    if not token:
        return
    with tx() as conn:
        conn.execute("DELETE FROM auth_tokens WHERE token = ?", (token,))


def purge_expired_tokens() -> int:
    with tx() as conn:
        cur = conn.execute("DELETE FROM auth_tokens WHERE expires_at <= datetime('now')")
        return cur.rowcount


def change_password(user_id: int, old_password: str, new_password: str) -> None:
    conn = get_conn()
    try:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    finally:
        conn.close()
    if row is None:
        raise AuthError("Không tìm thấy tài khoản.")
    if not hmac.compare_digest(_hash_password(old_password, row["salt"]), row["password_hash"]):
        raise AuthError("Mật khẩu hiện tại không đúng.")
    if len(new_password) < MIN_PASSWORD_LEN:
        raise AuthError(f"Mật khẩu mới phải có ít nhất {MIN_PASSWORD_LEN} ký tự.")

    salt = secrets.token_hex(16)
    with tx() as conn:
        conn.execute(
            "UPDATE users SET password_hash = ?, salt = ? WHERE id = ?",
            (_hash_password(new_password, salt), salt, user_id),
        )
