"""Bộ chạy tác tử bằng CrewAI.

Chỉ được nhập khi ``AGENT_FRAMEWORK=crewai``, nên bản cài mặc định không cần thư viện
này. Mỗi lượt gọi dựng một Crew gồm đúng một Agent và một Task rồi chạy — cách này giữ
số lời gọi LLM bằng đúng bản chạy gốc (một lượt = một lời gọi), vì luồng nghiệp vụ cần
chờ sinh viên nhập giữa các vòng nên không thể chạy cả crew trong một lần kickoff.

Đổi lại, vai trò của từng tác tử được framework mô hình hoá tường minh (role / goal /
backstory / expected_output), thuận cho việc mở rộng sau này: thêm tác tử, đổi sang
``Process.hierarchical``, hoặc gắn tool cho từng vai.
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import TYPE_CHECKING

from . import config
from .llm import LLMError

if TYPE_CHECKING:  # pragma: no cover
    from .agents import AgentSpec


def _require_crewai():
    # CrewAI hỏi tương tác về tracing ở lần chạy đầu và gửi telemetry ra ngoài.
    # Phải tắt TRƯỚC khi nhập thư viện, nếu không tiến trình chạy nền (systemd, PM2)
    # sẽ đứng chờ bàn phím.
    for name, value in (
        ("CREWAI_TELEMETRY_OPT_OUT", "true"),
        ("CREWAI_TRACING_ENABLED", "false"),
        ("OTEL_SDK_DISABLED", "true"),
    ):
        os.environ.setdefault(name, value)

    try:
        from crewai import LLM, Agent, Crew, Process, Task
    except ImportError as exc:  # pragma: no cover
        raise LLMError(
            "Chưa cài CrewAI. Chạy: pip install -r requirements-crewai.txt "
            "hoặc đặt AGENT_FRAMEWORK=native trong .env để dùng bộ chạy gốc."
        ) from exc
    return LLM, Agent, Crew, Process, Task


@lru_cache(maxsize=8)
def _build_agent(key: str, model: str, temperature: float):
    """Dựng (và nhớ lại) một Agent của CrewAI cho mỗi vai."""
    from .agents import AGENTS

    spec = AGENTS[key]
    LLM, Agent, _Crew, _Process, _Task = _require_crewai()

    llm = LLM(
        model=f"openai/{model}",
        api_key=config.OPENAI_API_KEY,
        temperature=temperature,
        max_tokens=spec.max_tokens,
    )
    return Agent(
        role=spec.role,
        goal=spec.goal,
        backstory=spec.backstory,
        llm=llm,
        verbose=False,
        allow_delegation=False,   # mỗi vai tự làm phần của mình, không uỷ thác
        max_iter=1,               # một lượt = đúng một lời gọi LLM
        cache=False,
    )


def run_task(spec: AgentSpec, prompt: str) -> str:
    """Giao một nhiệm vụ cho tác tử qua CrewAI và trả về văn bản kết quả."""
    _LLM, _Agent, Crew, Process, Task = _require_crewai()

    temperature = (
        config.LLM_TEMPERATURE if spec.temperature is None else spec.temperature
    )
    agent = _build_agent(spec.key, spec.model, temperature)

    expected = (
        "Một object JSON hợp lệ, không kèm giải thích hay khối mã."
        if spec.json_output
        else "Nội dung tiếng Việt theo đúng bố cục được yêu cầu, không thêm lời dẫn."
    )
    task = Task(description=prompt, expected_output=expected, agent=agent)

    crew = Crew(agents=[agent], tasks=[task], process=Process.sequential, verbose=False)
    try:
        result = crew.kickoff()
    except Exception as exc:  # lỗi mạng, hết hạn mức, sai cấu hình model...
        raise LLMError(f"CrewAI chạy thất bại: {exc}") from exc

    text = str(getattr(result, "raw", result) or "").strip()
    if not text:
        raise LLMError("CrewAI trả về nội dung rỗng.")
    return text


def available() -> bool:
    try:
        import crewai  # noqa: F401
    except ImportError:
        return False
    return True
