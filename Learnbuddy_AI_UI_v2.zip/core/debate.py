"""Lõi tranh biện: ra đề, phản biện từng vòng, và trọng tài chấm điểm.

Có hai chế độ nền kiến thức, tự chọn theo dữ liệu sẵn có của chương:

  * ``corpus`` — chương có ngữ liệu giải thích (data/corpus). Mọi lời gọi LLM đều
    được nạp đoạn truy hồi từ RAG kèm ràng buộc "chỉ dựa trên ngữ liệu".
  * ``bank``  — chương chỉ có ngân hàng câu hỏi (input/*.docx), không có tài liệu
    giải thích. Khi đó không thể ràng buộc theo ngữ liệu, hệ thống chuyển sang dùng
    kiến thức chuyên môn của mô hình nhưng siết chặt việc viện dẫn: cấm bịa số hiệu
    điều luật, văn bản, số liệu.
"""

from __future__ import annotations

import random
import re
from typing import Any

from . import agents, config, rag
from . import repository as repo
from .llm import LLMError
from .repository import (
    ROLE_AI_REBUTTAL,
    ROLE_USER_ANSWER,
    ROLE_USER_REBUTTAL,
)

MODE_CORPUS = "corpus"
MODE_BANK = "bank"
MODE_NONE = "none"

# --------------------------------------------------------------------- prompt nền

_COMMON_RULES = (
    "Bạn là trợ giảng đại học chuyên đóng vai NGƯỜI PHẢN BIỆN cho sinh viên luyện tập.\n"
    "Nguyên tắc bắt buộc:\n"
    "1. Phản biện vào LẬP LUẬN, không công kích người học.\n"
    "2. Viết tiếng Việt, văn phong học thuật nhưng dễ hiểu với sinh viên.\n"
    "3. Không tiết lộ toàn bộ đáp án; mục tiêu là buộc sinh viên tự suy nghĩ sâu hơn.\n"
)

_RULES_CORPUS = (
    "4. Chỉ dùng kiến thức trong phần NGỮ LIỆU được cung cấp. Nếu ngữ liệu không đủ để "
    "kết luận, hãy nói rõ 'ngữ liệu chưa đề cập' thay vì bịa.\n"
)

_RULES_BANK = (
    "4. Chương này CHƯA có tài liệu giải thích số hoá, phần dưới chỉ liệt kê PHẠM VI CHỦ ĐỀ "
    "(các câu hỏi ôn tập của giảng viên) — đó là chỉ dẫn phạm vi, KHÔNG phải dữ kiện để trích.\n"
    "5. Hãy dùng kiến thức chuyên môn chuẩn mực của bạn về môn học, bám sát phạm vi chủ đề trên.\n"
    "6. TUYỆT ĐỐI không bịa số hiệu điều luật, tên/số văn bản, năm ban hành hay số liệu cụ thể. "
    "Chỉ nêu tên văn bản khi thực sự chắc chắn; nếu không, hãy lập luận theo nguyên tắc chung "
    "và nói rõ sinh viên cần tự đối chiếu văn bản pháp luật hiện hành.\n"
)


def _rules(mode: str) -> str:
    return _COMMON_RULES + (_RULES_CORPUS if mode == MODE_CORPUS else _RULES_BANK)


def _question_instructions(mode: str) -> str:
    return (
        _rules(mode)
        + "\nNhiệm vụ hiện tại: RA MỘT CÂU HỎI ÔN TẬP duy nhất, đúng phạm vi chương.\n"
        "Chỉ trả về đúng nội dung câu hỏi, không thêm lời dẫn, không đánh số, "
        "không đưa gợi ý đáp án."
    )


def _rebuttal_instructions(mode: str) -> str:
    return (
        _rules(mode)
        + "\nNhiệm vụ hiện tại: ĐÁNH GIÁ NGẮN GỌN rồi PHẢN BIỆN phần trình bày mới nhất "
        "của sinh viên.\n"
        "Bố cục bắt buộc (dùng đúng các tiêu đề markdown sau):\n"
        "**Ghi nhận:** 1-2 câu nêu điểm đúng/đáng ghi nhận.\n"
        "**Điểm yếu:** 2-3 gạch đầu dòng chỉ ra chỗ sai, thiếu, hoặc lập luận hổng.\n"
        "**Phản biện:** một lập luận đối lập sắc bén hoặc một phản ví dụ cụ thể.\n"
        "**Câu hỏi truy vấn:** đúng MỘT câu hỏi buộc sinh viên phải bảo vệ lập trường.\n"
        "Tổng độ dài không quá 220 từ."
    )


_JUDGE_BASE = (
    "Bạn là TRỌNG TÀI học thuật, độc lập và công tâm, chấm một phiên tranh biện giữa "
    "SINH VIÊN và NGƯỜI PHẢN BIỆN (AI). Không thiên vị bên AI.\n"
    "Chấm theo 4 tiêu chí, mỗi tiêu chí 0-10 (số thực 1 chữ số thập phân):\n"
    "- do_chinh_xac: kiến thức sinh viên nêu có đúng chuyên môn không.\n"
    "- do_day_du: có bao phủ các ý cốt lõi của câu hỏi không.\n"
    "- chat_luong_lap_luan: tính logic, dẫn chứng, khả năng bảo vệ lập trường qua các vòng.\n"
    "- phan_hoi_phan_bien: mức độ trả lời trúng các chất vấn của người phản biện.\n"
    "diem_tong = trung bình 4 tiêu chí, thang 10.\n"
    "Trả về DUY NHẤT một object JSON theo đúng schema, tiếng Việt:\n"
    "{\n"
    '  "diem": {"do_chinh_xac": số, "do_day_du": số, "chat_luong_lap_luan": số, '
    '"phan_hoi_phan_bien": số},\n'
    '  "diem_tong": số,\n'
    '  "ben_thuyet_phuc_hon": "sinh_vien" | "ai" | "hoa",\n'
    '  "diem_manh": [chuỗi, 2-3 mục],\n'
    '  "diem_yeu": [chuỗi, 2-3 mục],\n'
    '  "kien_thuc_con_thieu": [chuỗi, 1-3 mục],\n'
    '  "dap_an_tham_khao": chuỗi 4-6 câu tóm tắt câu trả lời đúng,\n'
    '  "goi_y_cai_thien": [chuỗi, 2-3 lời khuyên hành động cụ thể],\n'
    '  "nhan_xet_chung": chuỗi 2-3 câu\n'
    "}"
)


def _judge_instructions(mode: str) -> str:
    if mode == MODE_CORPUS:
        return _JUDGE_BASE + "\nChỉ căn cứ vào NGỮ LIỆU môn học và nội dung tranh biện."
    return (
        _JUDGE_BASE
        + "\nChương này chưa có tài liệu giải thích số hoá; hãy căn cứ vào kiến thức chuyên môn "
        "chuẩn mực và nội dung tranh biện. Trong 'dap_an_tham_khao', không bịa số hiệu điều luật "
        "hay văn bản; nếu cần thì nhắc sinh viên đối chiếu văn bản pháp luật hiện hành."
    )


# ------------------------------------------------------------------ ngữ cảnh nền


def _bank_scope(chapter: dict[str, Any]) -> str:
    samples = repo.chapter_question_samples(chapter["id"])
    if not samples:
        return ""
    lines = "\n".join(f"- {q}" for q in samples)
    return (
        "PHẠM VI CHỦ ĐỀ CỦA CHƯƠNG (trích ngân hàng câu hỏi ôn tập, dùng để giới hạn "
        f"phạm vi, không phải dữ kiện):\n{lines}"
    )


_RE_OPTION_LINE = re.compile(r"^([A-Da-d])\s*[.)]\s*(\S.*)$")


def parse_choices(question: str) -> tuple[str, list[tuple[str, str]]]:
    """Tách câu trắc nghiệm thành (đề bài, danh sách phương án).

    Trả về danh sách rỗng nếu đây là câu tự luận. Dòng không phải phương án nhưng
    nằm sau một phương án được coi là phần nối tiếp của phương án đó (tài liệu gốc
    hay xuống dòng giữa chừng).
    """
    stem: list[str] = []
    options: list[tuple[str, str]] = []
    for raw in question.strip().split("\n"):
        line = raw.strip()
        if not line:
            continue
        match = _RE_OPTION_LINE.match(line)
        if match:
            options.append((match.group(1).upper(), match.group(2).strip()))
        elif options:
            letter, text = options[-1]
            options[-1] = (letter, f"{text} {line}")
        else:
            stem.append(line)
    if len(options) < 2:
        return question.strip(), []
    return "\n".join(stem).strip(), options


def chapter_mode(chapter: dict[str, Any]) -> str:
    """Xác định chế độ nền kiến thức của chương."""
    if chapter.get("chunk_count"):
        return MODE_CORPUS
    if chapter.get("question_count"):
        return MODE_BANK
    return MODE_NONE


def _context_for(chapter: dict[str, Any], query: str, top_k: int | None = None) -> tuple[str, str]:
    """Trả về (khối ngữ cảnh, chế độ)."""
    mode = chapter_mode(chapter)
    if mode == MODE_CORPUS:
        hits = rag.search(chapter["id"], query, top_k=top_k)
        if hits:
            return rag.format_context(hits), MODE_CORPUS
        mode = MODE_BANK
    scope = _bank_scope(chapter)
    return scope, MODE_BANK if scope else MODE_NONE


# ------------------------------------------------------------------------- ra đề


def generate_question(
    chapter: dict[str, Any], difficulty: str, avoid: list[str] | None = None
) -> dict[str, Any]:
    """Lấy câu hỏi cho phiên luyện tập.

    Ưu tiên bốc ngẫu nhiên trong ngân hàng câu hỏi của giảng viên đúng chương và
    đúng mức độ. Nếu mức độ đó chưa có câu nào, LLM sinh câu hỏi mới trong phạm vi
    chương. Trả về dict {question, context, source, mode, offline}.
    """
    banked = repo.pick_bank_question(chapter["id"], difficulty, exclude=avoid)
    if banked:
        context, mode = _context_for(chapter, banked["content"])
        return {
            "question": banked["content"],
            "context": context,
            "source": "bank",
            "bank_source": banked["source"],
            "mode": mode,
            "offline": False,
        }

    # --- không có sẵn trong ngân hàng: nhờ LLM ra đề trong phạm vi chương
    mode = chapter_mode(chapter)
    if mode == MODE_CORPUS:
        seed_chunks = rag.random_chunks(chapter["id"], k=2, seed=random.randrange(10**9))
        context = rag.format_context(seed_chunks)
        seed_heading = seed_chunks[0].heading if seed_chunks else chapter["title"]
    elif mode == MODE_BANK:
        context = _bank_scope(chapter)
        seed_heading = chapter.get("topic") or chapter["title"]
    else:
        raise LLMError(
            "Chương này chưa có ngữ liệu ôn tập lẫn ngân hàng câu hỏi. "
            "Hãy bổ sung tài liệu rồi đồng bộ lại."
        )

    avoid_block = ""
    if avoid:
        joined = "\n".join(f"- {q}" for q in avoid if q)
        avoid_block = f"\nCÁC CÂU ĐÃ HỎI GẦN ĐÂY (tránh lặp lại ý):\n{joined}\n"

    label = "NGỮ LIỆU" if mode == MODE_CORPUS else "PHẠM VI CHƯƠNG"
    user_prompt = (
        f"MÔN: {chapter['subject_name']}\nCHƯƠNG: {chapter['title']}\n"
        f"MỨC ĐỘ: {config.DIFFICULTY_SPEC[difficulty]}\n"
        f"{avoid_block}\n{label}:\n{context}\n\n"
        "Hãy ra một câu hỏi ôn tập đúng mức độ trên, nằm trong phạm vi chương."
    )

    try:
        question = agents.run(
            agents.QUESTION_SETTER, _question_instructions(mode), user_prompt
        ).output
        offline = False
    except LLMError as exc:
        if str(exc) != "OFFLINE":
            raise
        question = _offline_question(seed_heading, difficulty)
        offline = True

    return {
        "question": question.strip().strip('"'),
        "context": context,
        "source": "llm",
        "bank_source": None,
        "mode": mode,
        "offline": offline,
    }


# --------------------------------------------------------------------- phản biện


def _transcript(question: str, turns: list[dict[str, Any]]) -> str:
    label = {
        ROLE_USER_ANSWER: "SINH VIÊN (trả lời gốc)",
        ROLE_AI_REBUTTAL: "NGƯỜI PHẢN BIỆN (AI)",
        ROLE_USER_REBUTTAL: "SINH VIÊN (phản biện lại)",
    }
    lines = [f"CÂU HỎI: {question}", ""]
    for t in turns:
        lines.append(f"--- {label.get(t['role'], t['role'])} | vòng {t['round_no']} ---")
        lines.append(t["content"].strip())
        lines.append("")
    return "\n".join(lines)


def _retrieval_query(question: str, turns: list[dict[str, Any]]) -> str:
    """Ghép câu hỏi với lượt nói mới nhất của sinh viên làm truy vấn RAG."""
    last_student = ""
    for t in reversed(turns):
        if t["role"] in (ROLE_USER_ANSWER, ROLE_USER_REBUTTAL):
            last_student = t["content"]
            break
    return f"{question}\n{last_student}"[:2000]


def generate_rebuttal(
    chapter: dict[str, Any],
    difficulty: str,
    question: str,
    turns: list[dict[str, Any]],
    round_no: int,
) -> dict[str, Any]:
    """Sinh lượt phản biện thứ `round_no` của hệ thống."""
    context, mode = _context_for(chapter, _retrieval_query(question, turns))

    escalation = {
        1: "Đây là vòng 1: tập trung soi các lỗ hổng lớn nhất trong câu trả lời gốc.",
        2: "Đây là vòng 2: sinh viên đã phản biện lại. Đừng lặp lại ý cũ — hãy đào sâu hơn, "
           "kiểm tra xem phần phản biện của họ có thật sự giải quyết được chất vấn trước không.",
        3: "Đây là vòng 3 (vòng cuối): đưa ra thử thách khó nhất, một tình huống biên hoặc "
           "phản ví dụ mà lập trường của sinh viên khó xử lý.",
    }.get(round_no, "Hãy tiếp tục đào sâu vào điểm yếu còn lại.")

    _, choices = parse_choices(question)
    mcq_note = ""
    if choices:
        mcq_note = (
            "\nĐÂY LÀ CÂU TRẮC NGHIỆM. Sinh viên phải chọn một phương án và biện minh. "
            "Hãy soi cả hai: phương án đã chọn lẫn lý do chọn. Nếu họ chọn sai, TUYỆT ĐỐI "
            "không nói thẳng đáp án đúng — chỉ vạch ra chỗ hổng trong lập luận và hỏi lại "
            "để họ tự xét các phương án còn lại. Nếu họ chọn đúng nhưng lý do sai hoặc hời "
            "hợt, hãy chất vấn đúng chỗ đó.\n"
        )

    label = "NGỮ LIỆU" if mode == MODE_CORPUS else "PHẠM VI CHƯƠNG"
    user_prompt = (
        f"MÔN: {chapter['subject_name']}\nCHƯƠNG: {chapter['title']}\n"
        f"MỨC ĐỘ: {config.DIFFICULTY_SPEC[difficulty]}\n"
        f"GIỌNG ĐIỆU: {config.TONE_BY_DIFFICULTY[difficulty]}\n"
        f"VÒNG: {round_no}/{config.MAX_ROUNDS}. {escalation}\n{mcq_note}\n"
        f"{label}:\n{context}\n\n"
        f"DIỄN BIẾN TRANH BIỆN:\n{_transcript(question, turns)}\n"
        "Hãy viết lượt phản biện tiếp theo của bạn."
    )

    try:
        result = agents.run(agents.DEBATER, _rebuttal_instructions(mode), user_prompt)
        content, offline = result.output, False
    except LLMError as exc:
        if str(exc) != "OFFLINE":
            raise
        content = _offline_rebuttal(context, round_no)
        offline = True

    return {"content": content.strip(), "mode": mode, "offline": offline}


# --------------------------------------------------------------------- trọng tài


def judge(
    chapter: dict[str, Any],
    difficulty: str,
    question: str,
    turns: list[dict[str, Any]],
) -> dict[str, Any]:
    """Trọng tài LLM + RAG chấm toàn bộ phiên."""
    context, mode = _context_for(
        chapter, _retrieval_query(question, turns), top_k=config.TOP_K + 2
    )

    _, choices = parse_choices(question)
    mcq_note = (
        "\nĐÂY LÀ CÂU TRẮC NGHIỆM: chấm cả việc chọn đúng phương án lẫn chất lượng biện "
        "minh. Trong 'dap_an_tham_khao' hãy nêu rõ phương án đúng và lý do.\n"
        if choices
        else ""
    )

    label = "NGỮ LIỆU CHUẨN" if mode == MODE_CORPUS else "PHẠM VI CHƯƠNG"
    user_prompt = (
        f"MÔN: {chapter['subject_name']}\nCHƯƠNG: {chapter['title']}\n"
        f"MỨC ĐỘ ĐỀ: {config.DIFFICULTIES.get(difficulty, difficulty)}\n{mcq_note}\n"
        f"{label}:\n{context}\n\n"
        f"TOÀN BỘ PHIÊN TRANH BIỆN:\n{_transcript(question, turns)}\n"
        "Hãy chấm và trả về JSON theo schema đã quy định."
    )

    try:
        data = agents.run(agents.JUDGE, _judge_instructions(mode), user_prompt).data or {}
        data["offline"] = False
    except LLMError as exc:
        if str(exc) != "OFFLINE":
            raise
        data = _offline_verdict(context)

    verdict = _normalize_verdict(data)
    verdict["mode"] = mode
    return verdict


def _normalize_verdict(data: dict[str, Any]) -> dict[str, Any]:
    """Chuẩn hoá kết quả trọng tài để UI không vỡ khi model trả thiếu trường."""
    keys = ["do_chinh_xac", "do_day_du", "chat_luong_lap_luan", "phan_hoi_phan_bien"]
    raw_scores = data.get("diem") or {}
    scores: dict[str, float] = {}
    for k in keys:
        try:
            scores[k] = max(0.0, min(10.0, round(float(raw_scores.get(k, 0)), 1)))
        except (TypeError, ValueError):
            scores[k] = 0.0

    try:
        total = float(data.get("diem_tong"))
    except (TypeError, ValueError):
        total = sum(scores.values()) / len(keys)
    total = max(0.0, min(10.0, round(total, 1)))

    def as_list(value: Any) -> list[str]:
        if isinstance(value, list):
            return [str(v) for v in value if str(v).strip()]
        if isinstance(value, str) and value.strip():
            return [value.strip()]
        return []

    winner = str(data.get("ben_thuyet_phuc_hon", "hoa")).lower()
    if winner not in ("sinh_vien", "ai", "hoa"):
        winner = "hoa"

    return {
        "diem": scores,
        "diem_tong": total,
        "ben_thuyet_phuc_hon": winner,
        "diem_manh": as_list(data.get("diem_manh")),
        "diem_yeu": as_list(data.get("diem_yeu")),
        "kien_thuc_con_thieu": as_list(data.get("kien_thuc_con_thieu")),
        "dap_an_tham_khao": str(data.get("dap_an_tham_khao", "")).strip(),
        "goi_y_cai_thien": as_list(data.get("goi_y_cai_thien")),
        "nhan_xet_chung": str(data.get("nhan_xet_chung", "")).strip(),
        "offline": bool(data.get("offline", False)),
    }


# ------------------------------------------------------- đặt tên chủ đề cho chương


def suggest_chapter_topic(chapter: dict[str, Any]) -> str:
    """Đặt nhãn chủ đề ngắn cho chương dựa trên các câu hỏi ôn tập của nó.

    Dùng khi tài liệu gốc chỉ ghi tiêu đề chung chung như "Pháp luật 1". Gọi một
    lần cho mỗi chương rồi lưu vào CSDL.
    """
    samples = repo.chapter_question_samples(chapter["id"], limit=10)
    if not samples:
        return ""
    listed = "\n".join(f"- {q}" for q in samples)
    try:
        topic = agents.run(
            agents.TOPIC_LABELER,
            "Chỉ trả về một cụm danh từ tiếng Việt ngắn gọn (tối đa 8 từ) gọi tên chủ đề "
            "chung của các câu hỏi trên. Không dấu chấm câu, không giải thích.",
            f"Môn: {chapter['subject_name']}\nCác câu hỏi ôn tập của chương:\n{listed}",
        ).output
    except LLMError:
        return ""
    return topic.strip().strip('".').strip()


# --------------------------------------------------- dự phòng khi chưa có API key


def _first_sentence(text: str, limit: int = 180) -> str:
    clean = " ".join(text.split())
    for sep in (". ", "; "):
        if sep in clean[:limit]:
            return clean[: clean.index(sep) + 1]
    return clean[:limit] + ("..." if len(clean) > limit else "")


def _offline_question(topic: str, difficulty: str) -> str:
    topic = topic or "nội dung chương"
    templates = {
        "easy": f"Hãy trình bày khái niệm cốt lõi của «{topic}» và cho một ví dụ minh hoạ.",
        "medium": f"Hãy giải thích cơ chế hoạt động liên quan tới «{topic}», nêu ưu và nhược điểm.",
        "hard": (
            f"Có ý kiến cho rằng phần «{topic}» thường bị áp dụng máy móc trong thực tế. "
            "Bạn đồng ý hay phản đối? Hãy bảo vệ lập trường của mình."
        ),
    }
    return templates[difficulty]


def _offline_rebuttal(context: str, round_no: int) -> str:
    evidence = _first_sentence(context) if context else "ngữ liệu chương này"
    return (
        "> ⚠️ CHẾ ĐỘ NGOẠI TUYẾN — chưa cấu hình `OPENAI_API_KEY`, đây là phản biện mẫu.\n\n"
        "**Ghi nhận:** Bạn đã nêu được hướng tiếp cận cho câu hỏi.\n\n"
        "**Điểm yếu:**\n"
        "- Lập luận chưa gắn với dẫn chứng cụ thể từ giáo trình.\n"
        "- Chưa xét tới các trường hợp biên khiến kết luận không còn đúng.\n\n"
        f"**Phản biện:** Ngữ liệu chỉ ra rằng: {evidence} "
        "Điều này chưa được phần trả lời của bạn xử lý thoả đáng.\n\n"
        f"**Câu hỏi truy vấn:** (vòng {round_no}) Nếu giả định trên không còn đúng, "
        "kết luận của bạn sẽ thay đổi thế nào?"
    )


def _offline_verdict(context: str) -> dict[str, Any]:
    return {
        "diem": {
            "do_chinh_xac": 5.0,
            "do_day_du": 5.0,
            "chat_luong_lap_luan": 5.0,
            "phan_hoi_phan_bien": 5.0,
        },
        "diem_tong": 5.0,
        "ben_thuyet_phuc_hon": "hoa",
        "diem_manh": ["Đã hoàn thành đủ các vòng phản biện."],
        "diem_yeu": ["Không thể chấm chi tiết ở chế độ ngoại tuyến."],
        "kien_thuc_con_thieu": ["Xem lại nội dung chương"],
        "dap_an_tham_khao": (
            _first_sentence(context, 400) if context else "Chưa có ngữ liệu tham chiếu."
        ),
        "goi_y_cai_thien": [
            "Cấu hình OPENAI_API_KEY trong file .env để bật chấm điểm thật.",
        ],
        "nhan_xet_chung": "Kết quả mẫu ở chế độ ngoại tuyến, chỉ nhằm minh hoạ luồng nghiệp vụ.",
        "offline": True,
    }
