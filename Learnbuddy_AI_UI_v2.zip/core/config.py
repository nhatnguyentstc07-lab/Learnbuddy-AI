"""Cấu hình tập trung, đọc từ biến môi trường / file .env."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

DATA_DIR = BASE_DIR / "data"
CORPUS_DIR = DATA_DIR / "corpus"
MANIFEST_PATH = CORPUS_DIR / "manifest.json"
# Tài liệu thô của giảng viên (.docx ngân hàng câu hỏi) được nạp tự động
INPUT_DIR = BASE_DIR / "input"

_db_path = os.getenv("DB_PATH", "").strip()
DB_PATH = Path(_db_path) if _db_path else DATA_DIR / "app.db"
if not DB_PATH.is_absolute():
    DB_PATH = BASE_DIR / DB_PATH

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
CHAT_MODEL = os.getenv("CHAT_MODEL", "gpt-4o-mini").strip()
EMBED_MODEL = os.getenv("EMBED_MODEL", "text-embedding-3-small").strip()

# Số ngày giữ phiên đăng nhập sau lần hoạt động cuối
SESSION_TTL_DAYS = int(os.getenv("SESSION_TTL_DAYS", "7"))

# Tài khoản được phép mở trang "Tài liệu nguồn" (nạp lại học liệu).
# Nhiều email thì phân tách bằng dấu phẩy trong biến môi trường ADMIN_EMAILS.
ADMIN_EMAILS = {
    e.strip().lower()
    for e in os.getenv("ADMIN_EMAILS", "admin@gmail.com").split(",")
    if e.strip()
}


def is_admin(email: str | None) -> bool:
    return (email or "").strip().lower() in ADMIN_EMAILS


# Bộ ngữ liệu demo trong data/corpus (Cơ sở dữ liệu, Mạng máy tính, Nhập môn AI).
# Mặc định TẮT để danh sách môn học chỉ gồm tài liệu thật trong input/.
INCLUDE_DEMO_CORPUS = os.getenv("INCLUDE_DEMO_CORPUS", "false").strip().lower() in (
    "1", "true", "yes",
)

# Bộ chạy tác tử: "native" (gọi thẳng OpenAI) hoặc "crewai" (dựng Agent/Task/Crew).
# Cả hai dùng chung một model và cùng số lời gọi; xem core/agents.py.
AGENT_FRAMEWORK = os.getenv("AGENT_FRAMEWORK", "native").strip().lower()


def model_for(env_name: str) -> str:
    """Model dành riêng cho một vai, không khai thì dùng CHAT_MODEL chung."""
    if not env_name:
        return CHAT_MODEL
    return os.getenv(env_name, "").strip() or CHAT_MODEL


TOP_K = int(os.getenv("TOP_K", "4"))
MAX_ROUNDS = int(os.getenv("MAX_ROUNDS", "3"))
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.4"))

# Kích thước đoạn văn bản khi cắt ngữ liệu cho RAG (đơn vị: ký tự)
CHUNK_MAX_CHARS = 900
CHUNK_MIN_CHARS = 200

DIFFICULTIES = {
    "easy": "Dễ",
    "medium": "Trung bình",
    "hard": "Khó",
}

# Mô tả yêu cầu ra đề theo từng mức độ, dùng chèn thẳng vào prompt
DIFFICULTY_SPEC = {
    "easy": (
        "Mức DỄ: hỏi về định nghĩa, khái niệm nền tảng, phân biệt hai thuật ngữ gần nhau. "
        "Sinh viên chỉ cần nhớ và diễn đạt lại đúng ý là trả lời được."
    ),
    "medium": (
        "Mức TRUNG BÌNH: hỏi giải thích cơ chế, so sánh ưu/nhược điểm, hoặc áp dụng khái niệm "
        "vào một tình huống cụ thể nhỏ. Cần lập luận vài bước, không chỉ học thuộc."
    ),
    "hard": (
        "Mức KHÓ: đặt một nhận định gây tranh cãi hoặc một tình huống đánh đổi (trade-off) trong "
        "thực tế, buộc sinh viên phải chọn lập trường, bảo vệ bằng lý lẽ và lường trước phản ví dụ."
    ),
}

TONE_BY_DIFFICULTY = {
    "easy": "Giọng điệu ôn hoà, gợi mở, ưu tiên giúp sinh viên tự nhận ra chỗ thiếu.",
    "medium": "Giọng điệu chất vấn vừa phải, đòi hỏi sinh viên chứng minh từng bước lập luận.",
    "hard": "Giọng điệu phản biện sắc bén, tấn công thẳng vào điểm yếu logic, đưa phản ví dụ cụ thể.",
}


def offline_mode() -> bool:
    """True khi chưa cấu hình khoá API -> chạy chế độ ngoại tuyến."""
    return not OPENAI_API_KEY
