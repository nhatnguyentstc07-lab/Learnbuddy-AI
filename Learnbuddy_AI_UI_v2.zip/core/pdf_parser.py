"""Đọc giáo trình PDF thành ngữ liệu theo chương, phục vụ RAG.

Dùng ``extraction_mode="layout"`` của pypdf: chế độ mặc định chèn khoảng trắng vào
giữa từ với văn bản canh đều tiếng Việt ("quan h ệ pháp lu ật"), còn chế độ layout
giữ nguyên chữ và cả thụt đầu dòng — nhờ đó nhận được ranh giới đoạn văn.

Quy ước nhận dạng (đúng với giáo trình dạng chuẩn của các trường):
  - Bắt đầu chương : dòng ``CHƯƠNG N`` kèm tiêu đề in hoa ngay sau.
  - Kết thúc chương: mục ``CÂU HỎI ... ÔN TẬP`` hoặc ``TÀI LIỆU THAM KHẢO``.
  - Đề mục con    : ``1.2.`` / ``1.2.3.`` — được chuyển thành tiêu đề markdown.
  - Bỏ qua        : phần đầu sách, ``MỤC LỤC`` ở cuối, chú thích chân trang, watermark.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from .docx_parser import make_code

_RE_NOISE = re.compile(
    r"^\s*(?:\d{1,4}|lOMoARcPSD.*|Downloaded by .*|.*Studocu.*|Scan to open.*"
    r"|This document is available.*)\s*$",
    re.I,
)
_RE_FOOTNOTE = re.compile(r"^\s*\d{1,3}\s+(?:Xem\b|Sđd|Tlđd|Nxb\.|Trích)", re.I)
_RE_CHAPTER = re.compile(r"^\s*CH[ƯU][ƠO]NG\s+(\d+)\s*(.*)$", re.I)
# Một số PDF xuất chữ có dấu thành tên glyph "/uni1ED5" thay vì ký tự thật
_RE_GLYPH = re.compile(r"/uni([0-9A-Fa-f]{4})")

# Đoạn ngắn hơn ngưỡng này thì mốc "CHƯƠNG N" đó là dòng mục lục, không phải
# chỗ chương thật sự bắt đầu.
MIN_CHAPTER_CHARS = 2000
_RE_HEADING = re.compile(r"^\s*(\d+(?:\.\d+)+)\.?\s+(\S.*)$")
_RE_STOP = re.compile(r"C[ÂA]U\s+H[ỎO]I.*(?:ÔN\s+T[ẬA]P|TH[ẢA]O\s+LU[ẬA]N)|T[ÀA]I\s+LI[ỆE]U\s+THAM\s+KH[ẢA]O", re.I)
_RE_TOC = re.compile(r"^\s*M[ỤU]C\s+L[ỤU]C\s*$", re.I)

# Dòng in hoa mở đầu một mục bên trong chương, không phải phần của tên chương
_RE_SECTION_WORD = re.compile(
    r"^(M[ỤU]C\s*TI[ÊE]U|N[ỘO]I\s*DUNG|M[ỞO]\s*(B[ÀA]I|Đ[ẦA]U)|GI[ỚO]I\s*THI[ỆE]U"
    r"|T[ÓO]M\s*T[ẮA]T|C[ÂA]U\s*H[ỎO]I)",
    re.I,
)


def is_title_line(text: str) -> bool:
    """Dòng tiêu đề chương: toàn chữ in hoa, đủ dài. Dùng str.isupper() để đúng với
    mọi chữ có dấu tiếng Việt (Ý, Ữ, Ạ...) thay vì tự liệt kê lớp ký tự."""
    stripped = text.strip()
    if not 5 <= len(stripped) <= 120:
        return False
    letters = [c for c in stripped if c.isalpha()]
    return bool(letters) and all(c.isupper() for c in letters)

_PROPER_NOUNS = {
    "việt nam": "Việt Nam",
    "chxhcn": "CHXHCN",
    "nhà nước cộng hòa xã hội chủ nghĩa việt nam":
        "Nhà nước Cộng hòa xã hội chủ nghĩa Việt Nam",
}


@dataclass
class TextbookChapter:
    number: int
    title: str
    markdown: str


@dataclass
class ParsedTextbook:
    name: str
    code: str
    source: str
    chapters: list[TextbookChapter] = field(default_factory=list)

    @property
    def total_chars(self) -> int:
        return sum(len(c.markdown) for c in self.chapters)


def sentence_case(text: str) -> str:
    """Đưa tiêu đề IN HOA về dạng câu, giữ lại vài danh từ riêng thường gặp."""
    lowered = re.sub(r"\s+", " ", text).strip().lower()
    for needle, replacement in _PROPER_NOUNS.items():
        lowered = lowered.replace(needle, replacement)
    return lowered[:1].upper() + lowered[1:] if lowered else ""


# ------------------------------------------------------------------- đọc & làm sạch


def extract_lines(path: Path) -> list[str]:
    """Bóc toàn bộ dòng văn bản, đã bỏ nhiễu và cắt trước phần MỤC LỤC."""
    from pypdf import PdfReader  # nhập tại chỗ để chỉ cần khi thật sự dùng PDF

    reader = PdfReader(str(path))
    lines: list[str] = []
    for page in reader.pages:
        text = page.extract_text(extraction_mode="layout") or ""
        text = _RE_GLYPH.sub(lambda m: chr(int(m.group(1), 16)), text)
        for raw in text.split("\n"):
            if _RE_TOC.match(raw):
                # Mục lục ở cuối sách thì dừng hẳn; ở đầu sách thì chỉ là một dòng
                # lạc giữa phần đầu, cứ bỏ qua rồi đọc tiếp.
                if len(lines) > 400:
                    return lines
                continue
            if not raw.strip() or _RE_NOISE.match(raw) or _RE_FOOTNOTE.match(raw):
                continue
            lines.append(raw.rstrip())
    return lines


def _select_chapter_starts(
    lines: list[str], marks: list[tuple[int, int]]
) -> list[tuple[int, int]]:
    """Chọn đúng vị trí bắt đầu của từng chương trong danh sách mốc tìm được.

    Cùng một số chương thường xuất hiện nhiều lần: ở mục lục (đầu hoặc cuối sách),
    ở phần giới thiệu bố cục, ở tiêu đề chạy đầu trang. Cách phân biệt đáng tin
    nhất là xét khối lượng chữ đi sau mỗi mốc — dòng mục lục chỉ cách mốc kế tiếp
    vài trăm ký tự, còn chỗ chương thật sự bắt đầu thì kéo dài hàng chục nghìn.
    """
    if not marks:
        return []

    sizes: list[int] = []
    for pos, (index, _number) in enumerate(marks):
        end = marks[pos + 1][0] if pos + 1 < len(marks) else len(lines)
        sizes.append(sum(len(line) for line in lines[index:end]))

    kept = [mark for mark, size in zip(marks, sizes) if size >= MIN_CHAPTER_CHARS]
    if not kept:
        kept = marks

    starts: list[tuple[int, int]] = []
    seen: set[int] = set()
    for index, number in kept:
        if number not in seen:
            seen.add(number)
            starts.append((index, number))
    return starts


def _to_paragraphs(lines: list[str]) -> str:
    """Ghép dòng gãy do xuống dòng cứng; thụt đầu dòng báo hiệu đoạn mới."""
    paragraphs: list[str] = []
    buffer: list[str] = []

    def flush() -> None:
        if buffer:
            paragraphs.append(re.sub(r"\s+", " ", " ".join(buffer)).strip())
            buffer.clear()

    base_indent = min((len(ln) - len(ln.lstrip()) for ln in lines if ln.strip()), default=0)
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        indent = len(line) - len(line.lstrip())
        starts_paragraph = (
            indent > base_indent + 2
            or re.match(r"^[-–•]|^[a-zđ]\)|^\(\d+\)", stripped)
        )
        if starts_paragraph and buffer:
            flush()
        buffer.append(stripped)
    flush()
    return "\n\n".join(p for p in paragraphs if p)


# --------------------------------------------------------------------- phân tích


def parse_textbook(path: Path) -> ParsedTextbook:
    lines = extract_lines(path)

    # --- xác định vị trí bắt đầu từng chương
    marks: list[tuple[int, int]] = []  # (chỉ số dòng, số chương)
    for i, line in enumerate(lines):
        match = _RE_CHAPTER.match(line)
        if not match:
            continue
        rest = match.group(2).strip(" :-–—.")
        # Chỉ nhận dòng tiêu đề: "CHƯƠNG N" đứng một mình, hoặc "CHƯƠNG N: TÊN IN HOA".
        # Loại các câu văn xuôi mở đầu chương ("Chương 1 đề cập đến những nội dung...")
        # và các dòng mục lục viết hoa-thường lẫn lộn.
        if rest and not is_title_line(rest):
            continue
        marks.append((i, int(match.group(1))))
    unique_starts = _select_chapter_starts(lines, marks)

    chapters: list[TextbookChapter] = []
    for pos, (start, number) in enumerate(unique_starts):
        end = unique_starts[pos + 1][0] if pos + 1 < len(unique_starts) else len(lines)
        block = lines[start + 1 : end]

        # Tiêu đề chương: phần còn lại trên chính dòng "CHƯƠNG N", cộng các dòng in
        # hoa liền sau đó (tiêu đề dài thường bị ngắt thành 2-3 dòng)
        title_parts: list[str] = []
        inline = _RE_CHAPTER.match(lines[start]).group(2).strip(" :-–—.")
        if inline and is_title_line(inline):
            title_parts.append(inline)
        body_from = 0
        for offset, line in enumerate(block[:6]):
            if len(" ".join(title_parts)) > 110:
                break  # tiêu đề đã đủ dài, phần sau là nội dung
            if _RE_SECTION_WORD.match(line.strip()):
                break  # đã sang mục con của chương
            if is_title_line(line) and not _RE_HEADING.match(line):
                title_parts.append(line.strip())
                body_from = offset + 1
            elif title_parts or line.strip():
                break
        title = sentence_case(" ".join(title_parts)) or f"Chương {number}"

        # Cắt bỏ phần câu hỏi ôn tập / tài liệu tham khảo ở cuối chương
        body = block[body_from:]
        for offset, line in enumerate(body):
            if _RE_STOP.search(line):
                body = body[:offset]
                break
        if not body:
            continue

        # Chuyển đề mục đánh số thành tiêu đề markdown để tận dụng bộ cắt đoạn của RAG
        sections: list[str] = []
        buffer: list[str] = []
        for line in body:
            heading = _RE_HEADING.match(line)
            if heading and len(line.strip()) < 120:
                if buffer:
                    sections.append(_to_paragraphs(buffer))
                    buffer = []
                sections.append(f"## {heading.group(1)}. {heading.group(2).strip()}")
            else:
                buffer.append(line)
        if buffer:
            sections.append(_to_paragraphs(buffer))

        markdown = f"# {title}\n\n" + "\n\n".join(s for s in sections if s.strip())
        chapters.append(TextbookChapter(number=number, title=title, markdown=markdown))

    stem = re.sub(r"^giao[\s\-_]*trinh[\s\-_]*", "", path.stem, flags=re.I)
    name = re.sub(r"[\-_]+", " ", stem).strip(" -_")
    return ParsedTextbook(
        name=name, code=make_code(name), source=path.name, chapters=chapters
    )
