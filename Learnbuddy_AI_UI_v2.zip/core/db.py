"""Kết nối và lược đồ SQLite."""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from typing import Iterator

from .config import DB_PATH

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT    NOT NULL,
    email         TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT    NOT NULL,
    salt          TEXT    NOT NULL,
    is_active     INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Token giữ phiên đăng nhập qua lần tải lại trang
CREATE TABLE IF NOT EXISTS auth_tokens (
    token      TEXT    PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT    NOT NULL DEFAULT (datetime('now')),
    expires_at TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_auth_tokens_user ON auth_tokens(user_id);

CREATE TABLE IF NOT EXISTS subjects (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    code  TEXT NOT NULL UNIQUE,
    name  TEXT NOT NULL,
    description TEXT
);

CREATE TABLE IF NOT EXISTS chapters (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    code       TEXT    NOT NULL,
    title      TEXT    NOT NULL,
    ord        INTEGER NOT NULL DEFAULT 0,
    topic      TEXT,
    UNIQUE (subject_id, code)
);

-- Ngân hàng câu hỏi ôn tập nhập từ tài liệu thật (thư mục input/)
CREATE TABLE IF NOT EXISTS questions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_id INTEGER NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
    difficulty TEXT    NOT NULL,
    ord        INTEGER NOT NULL DEFAULT 0,
    content    TEXT    NOT NULL,
    source     TEXT,
    UNIQUE (chapter_id, difficulty, content)
);
CREATE INDEX IF NOT EXISTS idx_questions_pick ON questions(chapter_id, difficulty);

-- Ghi vết tài liệu đã nạp: dùng để bỏ qua file không đổi, phát hiện file mới /
-- file sửa nội dung, và dọn dữ liệu của file đã bị xoá khỏi thư mục input.
CREATE TABLE IF NOT EXISTS ingest_files (
    path        TEXT PRIMARY KEY,
    sha         TEXT NOT NULL,
    kind        TEXT,            -- docx | pdf | md
    summary     TEXT,            -- tóm tắt đã nạp được gì
    size_bytes  INTEGER,
    first_seen  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS documents (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_id INTEGER NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
    path       TEXT    NOT NULL UNIQUE,
    sha        TEXT    NOT NULL,
    updated_at TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS chunks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chapter_id  INTEGER NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
    ord         INTEGER NOT NULL,
    heading     TEXT,
    content     TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chunks_chapter ON chunks(chapter_id);

CREATE TABLE IF NOT EXISTS embeddings (
    chunk_id INTEGER PRIMARY KEY REFERENCES chunks(id) ON DELETE CASCADE,
    model    TEXT NOT NULL,
    dim      INTEGER NOT NULL,
    vector   BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    chapter_id  INTEGER NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
    difficulty  TEXT    NOT NULL,
    question    TEXT    NOT NULL,
    context     TEXT,
    status      TEXT    NOT NULL DEFAULT 'open',
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id, id DESC);

CREATE TABLE IF NOT EXISTS turns (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    round_no   INTEGER NOT NULL,
    role       TEXT    NOT NULL,          -- user_answer | ai_rebuttal | user_rebuttal
    content    TEXT    NOT NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_turns_session ON turns(session_id, id);

CREATE TABLE IF NOT EXISTS verdicts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER NOT NULL UNIQUE REFERENCES sessions(id) ON DELETE CASCADE,
    total_score  REAL    NOT NULL,
    winner       TEXT    NOT NULL,
    payload_json TEXT    NOT NULL,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);
"""


def get_conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def tx() -> Iterator[sqlite3.Connection]:
    """Transaction: tự commit khi thành công, rollback khi lỗi."""
    conn = get_conn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _migrate(conn: sqlite3.Connection) -> None:
    """Bổ sung cột mới cho CSDL đã tồn tại từ phiên bản trước."""
    chapter_cols = {row["name"] for row in conn.execute("PRAGMA table_info(chapters)")}
    if "topic" not in chapter_cols:
        conn.execute("ALTER TABLE chapters ADD COLUMN topic TEXT")

    file_cols = {row["name"] for row in conn.execute("PRAGMA table_info(ingest_files)")}
    for column, ddl in (
        ("kind", "ALTER TABLE ingest_files ADD COLUMN kind TEXT"),
        ("summary", "ALTER TABLE ingest_files ADD COLUMN summary TEXT"),
        ("size_bytes", "ALTER TABLE ingest_files ADD COLUMN size_bytes INTEGER"),
        ("first_seen", "ALTER TABLE ingest_files ADD COLUMN first_seen TEXT"),
    ):
        if column not in file_cols:
            conn.execute(ddl)


def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = get_conn()
    try:
        conn.executescript("PRAGMA journal_mode = WAL;")
        conn.executescript(SCHEMA)
        _migrate(conn)
        conn.commit()
    finally:
        conn.close()
