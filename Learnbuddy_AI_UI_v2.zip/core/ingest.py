"""Nạp dữ liệu ôn tập vào SQLite, có ghi vết từng tài liệu.

Ba nguồn:
  - input/*.docx      : ngân hàng câu hỏi của giảng viên, phân theo chương và
                        nhóm độ khó. Một file có thể chứa nhiều học phần.
  - input/*.pdf       : giáo trình, bóc theo chương thành ngữ liệu cho RAG.
  - data/corpus/*.md  : ngữ liệu demo viết tay (mặc định TẮT, bật bằng biến môi
                        trường INCLUDE_DEMO_CORPUS=true).

Mỗi file được ghi vết trong bảng ``ingest_files`` kèm SHA nội dung. Nhờ đó lần nạp
sau chỉ xử lý file mới hoặc file đã sửa, và dữ liệu của file bị xoá khỏi thư mục
input cũng được dọn theo.

Ghép tài liệu vào môn học:
  - Ngân hàng câu hỏi tự khai tên môn qua dòng "Học phần N: <tên môn>".
  - Giáo trình ghép vào môn đã có khi mọi từ trong tên môn xuất hiện trong tên
    file. Trường hợp tên không khớp (giáo trình "Tin học quản lý" dùng cho môn
    "Ứng dụng công nghệ thông tin căn bản") thì khai báo trong input/mapping.json.
"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from pathlib import Path
from typing import Any

from . import config, docx_parser, pdf_parser, rag
from .db import get_conn, tx

MAPPING_PATH = "mapping.json"


# ------------------------------------------------------------------ tiện ích


def _sha_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _sha_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _name_tokens(text: str) -> set[str]:
    return {
        t for t in re.split(r"[^a-z0-9]+", docx_parser.strip_accents(text).lower()) if t
    }


def _load_mapping() -> dict[str, str]:
    """Đọc input/mapping.json: {"tên file": "tên môn"}."""
    path = config.INPUT_DIR / MAPPING_PATH
    if not path.exists():
        return {}
    try:
        with path.open(encoding="utf-8") as fh:
            data = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return {}
    files = data.get("files", data)
    return {k: v for k, v in files.items() if isinstance(v, str) and not k.startswith("_")}


def _input_files(suffix: str) -> list[Path]:
    if not config.INPUT_DIR.exists():
        return []
    return sorted(
        p
        for p in config.INPUT_DIR.glob(f"*{suffix}")
        if not p.name.startswith("~$") and p.is_file()
    )


def _record_file(conn: sqlite3.Connection, key: str, path: Path, sha: str,
                 kind: str, summary: str) -> None:
    conn.execute(
        "INSERT INTO ingest_files (path, sha, kind, summary, size_bytes) "
        "VALUES (?,?,?,?,?) "
        "ON CONFLICT(path) DO UPDATE SET sha = excluded.sha, kind = excluded.kind, "
        "summary = excluded.summary, size_bytes = excluded.size_bytes, "
        "updated_at = datetime('now')",
        (key, sha, kind, summary, path.stat().st_size),
    )


def _upsert_subject(conn: sqlite3.Connection, code: str, name: str, note: str) -> int:
    conn.execute(
        "INSERT INTO subjects (code, name, description) VALUES (?,?,?) "
        "ON CONFLICT(code) DO UPDATE SET name = excluded.name",
        (code, name, note),
    )
    return conn.execute("SELECT id FROM subjects WHERE code = ?", (code,)).fetchone()["id"]


def _upsert_chapter(conn: sqlite3.Connection, subject_id: int, number: int,
                    title: str) -> int:
    code = f"C{number}"
    row = conn.execute(
        "SELECT id FROM chapters WHERE subject_id = ? AND code = ?", (subject_id, code)
    ).fetchone()
    if row:
        return row["id"]
    cur = conn.execute(
        "INSERT INTO chapters (subject_id, code, title, ord) VALUES (?,?,?,?)",
        (subject_id, code, title, number),
    )
    return int(cur.lastrowid)


_RE_GENERIC_TITLE = re.compile(r"^(?:Chương\s*\d+|[^\d]{0,26}\s\d+)$", re.I)


def _is_generic_title(title: str) -> bool:
    """Tiêu đề kiểu "Chương 3" hay "Pháp luật 4" — không nói lên nội dung gì."""
    body = re.sub(r"^Chương\s*\d+\s*[—–-]\s*", "", title).strip()
    return not body or bool(_RE_GENERIC_TITLE.match(body))


# ------------------------------------------------- ngân hàng câu hỏi từ .docx


def sync_question_banks(force: bool = False) -> dict[str, Any]:
    """Nạp toàn bộ .docx trong input/ thành ngân hàng câu hỏi.

    Ngân hàng câu hỏi phân tích rất nhanh (dưới một giây cho cả thư mục) và nhiều
    file có thể cùng đóng góp câu hỏi cho một chương, nên khi có bất kỳ thay đổi
    nào ta nạp lại toàn bộ — cách này luôn cho kết quả nhất quán.
    """
    files = _input_files(".docx")
    result: dict[str, Any] = {
        "files": len(files), "changed": [], "unchanged": [], "subjects": 0, "questions": 0,
    }
    if not files:
        return result

    conn = get_conn()
    try:
        known = {
            row["path"]: row["sha"]
            for row in conn.execute("SELECT path, sha FROM ingest_files WHERE kind = 'docx'")
        }
    finally:
        conn.close()

    shas = {f"input/{p.name}": _sha_file(p) for p in files}
    changed = [k for k, sha in shas.items() if known.get(k) != sha]
    removed = [k for k in known if k not in shas]
    result["changed"] = [k.split("/", 1)[1] for k in changed]
    result["unchanged"] = [
        k.split("/", 1)[1] for k in shas if k not in changed
    ]
    if not changed and not removed and not force:
        conn = get_conn()
        try:
            result["questions"] = conn.execute("SELECT COUNT(*) c FROM questions").fetchone()["c"]
        finally:
            conn.close()
        return result

    parsed: list[tuple[Path, list]] = [(p, docx_parser.parse_docx(p)) for p in files]

    with tx() as conn:
        conn.execute("DELETE FROM questions")
        subject_codes: set[str] = set()

        for path, subjects in parsed:
            key = f"input/{path.name}"
            counts = []
            for subject in subjects:
                subject_id = _upsert_subject(
                    conn, subject.code, subject.name, "Ngân hàng câu hỏi ôn tập"
                )
                subject_codes.add(subject.code)
                for chapter in subject.chapters:
                    chapter_id = _upsert_chapter(
                        conn, subject_id, chapter.number,
                        f"Chương {chapter.number} — {chapter.title}",
                    )
                    for difficulty, items in chapter.questions.items():
                        for i, content in enumerate(items):
                            conn.execute(
                                "INSERT OR IGNORE INTO questions "
                                "(chapter_id, difficulty, ord, content, source) "
                                "VALUES (?,?,?,?,?)",
                                (chapter_id, difficulty, i, content, path.name),
                            )
                counts.append(f"{subject.name} ({subject.total_questions} câu)")

            _record_file(
                conn, key, path, shas[key], "docx",
                " · ".join(counts) if counts else "không nhận dạng được câu hỏi",
            )

        for key in removed:
            conn.execute("DELETE FROM ingest_files WHERE path = ?", (key,))

        result["subjects"] = len(subject_codes)
        result["questions"] = conn.execute(
            "SELECT COUNT(*) c FROM questions"
        ).fetchone()["c"]

    result["removed"] = [k.split("/", 1)[1] for k in removed]
    return result


# ------------------------------------------------------- giáo trình từ .pdf


def _match_subject_id(conn: sqlite3.Connection, name: str) -> int | None:
    """Ghép giáo trình vào môn đã có, khớp theo TẬP TỪ của tên môn.

    Không dùng so chuỗi con: mã môn ngắn dễ lọt vào mã môn khác (ví dụ "AI" nằm
    trong "PHAP_LUAT_DAI_CUONG"). Điều kiện: toàn bộ từ trong tên môn phải xuất
    hiện trong tên giáo trình, và tên môn có từ 2 từ trở lên.
    """
    book_tokens = _name_tokens(name)
    best: tuple[int, int] | None = None
    for row in conn.execute("SELECT id, name FROM subjects").fetchall():
        tokens = _name_tokens(row["name"])
        if len(tokens) >= 2 and tokens <= book_tokens:
            if best is None or len(tokens) > best[0]:
                best = (len(tokens), row["id"])
    return best[1] if best else None


def _resolve_subject(conn: sqlite3.Connection, path: Path, book_name: str,
                     mapping: dict[str, str]) -> tuple[int, str]:
    """Xác định môn cho một giáo trình. Trả về (subject_id, cách ghép)."""
    declared = mapping.get(path.name)
    if declared:
        row = conn.execute(
            "SELECT id FROM subjects WHERE name = ? COLLATE NOCASE", (declared,)
        ).fetchone()
        if row:
            return row["id"], "mapping.json"
        code = docx_parser.make_code(declared)
        return _upsert_subject(conn, code, declared, "Giáo trình"), "mapping.json (môn mới)"

    matched = _match_subject_id(conn, book_name)
    if matched is not None:
        return matched, "khớp tên môn"

    code = docx_parser.make_code(book_name)
    return _upsert_subject(conn, code, book_name, "Giáo trình"), "tạo môn mới"


def _ingest_textbook(conn: sqlite3.Connection, path: Path, sha: str,
                     mapping: dict[str, str]) -> str:
    book = pdf_parser.parse_textbook(path)
    if not book.chapters:
        return "không tách được chương nào"

    subject_id, how = _resolve_subject(conn, path, book.name, mapping)
    key = f"input/{path.name}"
    total_chunks = 0

    for chapter in book.chapters:
        chapter_id = _upsert_chapter(
            conn, subject_id, chapter.number,
            f"Chương {chapter.number} — {chapter.title}",
        )
        # Giáo trình là nguồn chuẩn cho phần mô tả nội dung chương; riêng tiêu đề
        # thì chỉ ghi đè khi tiêu đề hiện tại vô nghĩa ("Chương 3", "Pháp luật 4").
        current = conn.execute(
            "SELECT title FROM chapters WHERE id = ?", (chapter_id,)
        ).fetchone()["title"]
        if _is_generic_title(current):
            conn.execute(
                "UPDATE chapters SET title = ?, topic = ? WHERE id = ?",
                (f"Chương {chapter.number} — {chapter.title}", chapter.title, chapter_id),
            )
        else:
            conn.execute(
                "UPDATE chapters SET topic = ? WHERE id = ?", (chapter.title, chapter_id)
            )

        doc_path = f"{key}#C{chapter.number}"
        old = conn.execute("SELECT id FROM documents WHERE path = ?", (doc_path,)).fetchone()
        if old:
            conn.execute("DELETE FROM chunks WHERE document_id = ?", (old["id"],))
            conn.execute(
                "UPDATE documents SET sha = ?, chapter_id = ?, updated_at = datetime('now') "
                "WHERE id = ?",
                (sha, chapter_id, old["id"]),
            )
            document_id = old["id"]
        else:
            cur = conn.execute(
                "INSERT INTO documents (chapter_id, path, sha) VALUES (?,?,?)",
                (chapter_id, doc_path, sha),
            )
            document_id = int(cur.lastrowid)

        for i, (heading, body) in enumerate(rag.split_markdown(chapter.markdown)):
            conn.execute(
                "INSERT INTO chunks (document_id, chapter_id, ord, heading, content) "
                "VALUES (?,?,?,?,?)",
                (document_id, chapter_id, i, heading, body),
            )
            total_chunks += 1

    subject_name = conn.execute(
        "SELECT name FROM subjects WHERE id = ?", (subject_id,)
    ).fetchone()["name"]
    return f"{subject_name} — {len(book.chapters)} chương, {total_chunks} đoạn ({how})"


def sync_textbooks(force: bool = False) -> dict[str, Any]:
    """Nạp giáo trình .pdf. Tốn thời gian nên chỉ xử lý file mới hoặc đã sửa."""
    files = _input_files(".pdf")
    result: dict[str, Any] = {
        "files": len(files), "changed": [], "unchanged": [], "removed": [], "chunks": 0,
    }
    if not files and not config.INPUT_DIR.exists():
        return result

    mapping = _load_mapping()
    conn = get_conn()
    try:
        known = {
            row["path"]: row["sha"]
            for row in conn.execute("SELECT path, sha FROM ingest_files WHERE kind = 'pdf'")
        }
    finally:
        conn.close()

    shas = {f"input/{p.name}": _sha_file(p) for p in files}

    for path in files:
        key = f"input/{path.name}"
        if known.get(key) == shas[key] and not force:
            result["unchanged"].append(path.name)
            continue
        with tx() as conn:
            summary = _ingest_textbook(conn, path, shas[key], mapping)
            _record_file(conn, key, path, shas[key], "pdf", summary)
        result["changed"].append(path.name)

    # Dọn dữ liệu của giáo trình đã bị xoá khỏi thư mục input
    for key in [k for k in known if k not in shas]:
        with tx() as conn:
            conn.execute("DELETE FROM documents WHERE path LIKE ?", (f"{key}#%",))
            conn.execute("DELETE FROM ingest_files WHERE path = ?", (key,))
        result["removed"].append(key.split("/", 1)[1])

    conn = get_conn()
    try:
        result["chunks"] = conn.execute("SELECT COUNT(*) c FROM chunks").fetchone()["c"]
    finally:
        conn.close()
    return result


# --------------------------------------------------- ngữ liệu demo (data/corpus)


def _load_manifest() -> list[dict]:
    if not config.MANIFEST_PATH.exists():
        return []
    with config.MANIFEST_PATH.open(encoding="utf-8") as fh:
        return json.load(fh)["subjects"]


def sync_corpus() -> dict[str, int]:
    """Nạp ngữ liệu markdown viết tay trong data/corpus (bộ demo)."""
    updated = 0
    if not config.INCLUDE_DEMO_CORPUS:
        return {"updated_documents": 0}

    with tx() as conn:
        for subject in _load_manifest():
            subject_id = _upsert_subject(
                conn, subject["code"], subject["name"], subject.get("description", "")
            )
            for c_ord, chapter in enumerate(subject["chapters"]):
                conn.execute(
                    "INSERT INTO chapters (subject_id, code, title, ord) VALUES (?,?,?,?) "
                    "ON CONFLICT(subject_id, code) DO UPDATE SET title = excluded.title",
                    (subject_id, chapter["code"], chapter["title"], c_ord),
                )
                chapter_id = conn.execute(
                    "SELECT id FROM chapters WHERE subject_id = ? AND code = ?",
                    (subject_id, chapter["code"]),
                ).fetchone()["id"]

                path = config.CORPUS_DIR / chapter["file"]
                if not path.exists():
                    continue
                text = path.read_text(encoding="utf-8")
                sha = _sha_text(text)
                rel = chapter["file"]

                existing = conn.execute(
                    "SELECT id, sha FROM documents WHERE path = ?", (rel,)
                ).fetchone()
                if existing and existing["sha"] == sha:
                    continue
                if existing:
                    conn.execute("DELETE FROM chunks WHERE document_id = ?", (existing["id"],))
                    conn.execute(
                        "UPDATE documents SET sha = ?, chapter_id = ?, "
                        "updated_at = datetime('now') WHERE id = ?",
                        (sha, chapter_id, existing["id"]),
                    )
                    document_id = existing["id"]
                else:
                    cur = conn.execute(
                        "INSERT INTO documents (chapter_id, path, sha) VALUES (?,?,?)",
                        (chapter_id, rel, sha),
                    )
                    document_id = cur.lastrowid

                for i, (heading, body) in enumerate(rag.split_markdown(text)):
                    conn.execute(
                        "INSERT INTO chunks (document_id, chapter_id, ord, heading, content) "
                        "VALUES (?,?,?,?,?)",
                        (document_id, chapter_id, i, heading, body),
                    )
                updated += 1

    return {"updated_documents": updated}


# ------------------------------------------------------------- dọn dẹp & reset


def cleanup_empty() -> dict[str, int]:
    """Xoá các chương và môn không còn câu hỏi lẫn ngữ liệu nào."""
    with tx() as conn:
        cur = conn.execute(
            "DELETE FROM chapters WHERE id IN ("
            "  SELECT ch.id FROM chapters ch"
            "  WHERE NOT EXISTS (SELECT 1 FROM questions q WHERE q.chapter_id = ch.id)"
            "    AND NOT EXISTS (SELECT 1 FROM chunks k WHERE k.chapter_id = ch.id))"
        )
        chapters = cur.rowcount
        cur = conn.execute(
            "DELETE FROM subjects WHERE id IN ("
            "  SELECT s.id FROM subjects s"
            "  WHERE NOT EXISTS (SELECT 1 FROM chapters ch WHERE ch.subject_id = s.id))"
        )
        subjects = cur.rowcount
    return {"chapters": chapters, "subjects": subjects}


def reset_content() -> None:
    """Xoá sạch dữ liệu học liệu để nạp lại từ đầu.

    Xoá môn học sẽ kéo theo chương, câu hỏi, tài liệu, đoạn ngữ liệu, vector và
    cả các phiên tranh biện gắn với chúng. Tài khoản người dùng được giữ nguyên.
    """
    with tx() as conn:
        conn.execute("DELETE FROM subjects")
        conn.execute("DELETE FROM ingest_files")


def tracked_files() -> list[dict[str, Any]]:
    """Danh sách tài liệu đã nạp kèm trạng thái so với thư mục input hiện tại."""
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT path, sha, kind, summary, size_bytes, first_seen, updated_at "
            "FROM ingest_files ORDER BY kind, path"
        ).fetchall()
    finally:
        conn.close()

    tracked = {row["path"]: dict(row) for row in rows}
    on_disk = {
        f"input/{p.name}": p for p in _input_files(".docx") + _input_files(".pdf")
    }

    out: list[dict[str, Any]] = []
    for key, row in tracked.items():
        path = on_disk.get(key)
        if path is None:
            row["status"] = "đã xoá khỏi input"
        elif _sha_file(path) != row["sha"]:
            row["status"] = "đã sửa, cần nạp lại"
        else:
            row["status"] = "đã nạp"
        row["name"] = key.split("/", 1)[-1]
        out.append(row)

    for key, path in on_disk.items():
        if key not in tracked:
            out.append({
                "path": key, "name": path.name, "kind": path.suffix.lstrip("."),
                "summary": "", "size_bytes": path.stat().st_size,
                "first_seen": None, "updated_at": None, "status": "file mới, chưa nạp",
            })
    return out


# --------------------------------------------------------------- đồng bộ tất cả


def sync_all(force_docx: bool = False, force_pdf: bool = False) -> dict[str, Any]:
    """Đồng bộ mọi nguồn dữ liệu và trả về báo cáo chi tiết."""
    corpus = sync_corpus()
    bank = sync_question_banks(force=force_docx)
    books = sync_textbooks(force=force_pdf)
    cleaned = cleanup_empty()

    conn = get_conn()
    try:
        totals = conn.execute(
            "SELECT (SELECT COUNT(*) FROM subjects) AS subjects,"
            " (SELECT COUNT(*) FROM chapters) AS chapters,"
            " (SELECT COUNT(*) FROM chunks) AS chunks,"
            " (SELECT COUNT(*) FROM questions) AS questions"
        ).fetchone()
    finally:
        conn.close()

    return {
        "subjects": totals["subjects"],
        "chapters": totals["chapters"],
        "chunks": totals["chunks"],
        "questions": totals["questions"],
        "updated_documents": corpus["updated_documents"],
        "docx": bank,
        "pdf": books,
        "cleaned": cleaned,
    }
