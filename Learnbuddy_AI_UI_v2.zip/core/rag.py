"""RAG tối giản: chunk lưu trong SQLite, vector lưu dạng BLOB, tìm kiếm bằng NumPy.

Có hai chế độ truy hồi:
  - Vector (cosine) khi đã sinh embedding.
  - Từ vựng (TF-IDF thô) khi chưa có embedding / chưa cấu hình khoá API.
Nhờ vậy luồng nghiệp vụ vẫn chạy được ở chế độ ngoại tuyến.
"""

from __future__ import annotations

import math
import random
import re
import sqlite3
from collections import Counter
from dataclasses import dataclass
from typing import Any

import numpy as np

from . import config, llm
from .db import get_conn, tx

_TOKEN_RE = re.compile(r"[0-9a-zA-ZÀ-ỹ]+", re.UNICODE)

_STOPWORDS = {
    "và", "là", "của", "có", "các", "cho", "được", "trong", "một", "những", "khi",
    "này", "đó", "với", "để", "thì", "nếu", "như", "hoặc", "nhưng", "cũng", "sẽ",
    "the", "a", "an", "of", "to", "is", "are", "in", "on", "for", "that", "it",
}


@dataclass(frozen=True)
class Chunk:
    id: int
    chapter_id: int
    heading: str
    content: str
    score: float = 0.0

    def cite(self) -> str:
        return f"[#{self.id}] {self.heading}" if self.heading else f"[#{self.id}]"


# ------------------------------------------------------------------ cắt ngữ liệu


def _split_long_paragraphs(paragraphs: list[str]) -> list[str]:
    """Đoạn văn dài hơn ngưỡng thì cắt tiếp theo ranh giới câu.

    Văn bản bóc từ PDF nhiều khi có đoạn rất dài không chứa dòng trống nào; nếu
    không cắt thì cả đoạn thành một chunk khổng lồ, làm loãng kết quả truy hồi.
    """
    result: list[str] = []
    for para in paragraphs:
        if len(para) <= config.CHUNK_MAX_CHARS:
            result.append(para)
            continue
        sentences = re.split(r"(?<=[.!?;:])\s+", para)
        current: list[str] = []
        size = 0
        for sentence in sentences:
            if size + len(sentence) > config.CHUNK_MAX_CHARS and current:
                result.append(" ".join(current))
                current, size = [], 0
            current.append(sentence)
            size += len(sentence) + 1
        if current:
            result.append(" ".join(current))
    return result


def split_markdown(text: str) -> list[tuple[str, str]]:
    """Cắt markdown thành các (heading, nội dung) không quá CHUNK_MAX_CHARS ký tự."""
    sections: list[tuple[str, str]] = []
    heading = ""
    buffer: list[str] = []

    for line in text.splitlines():
        if line.startswith("#"):
            if buffer:
                sections.append((heading, "\n".join(buffer).strip()))
                buffer = []
            heading = line.lstrip("#").strip()
        else:
            buffer.append(line)
    if buffer:
        sections.append((heading, "\n".join(buffer).strip()))

    chunks: list[tuple[str, str]] = []
    for head, body in sections:
        if not body:
            continue
        if len(body) <= config.CHUNK_MAX_CHARS:
            chunks.append((head, body))
            continue
        # Gom từng đoạn văn cho tới khi chạm ngưỡng
        current: list[str] = []
        size = 0
        for para in _split_long_paragraphs(re.split(r"\n\s*\n", body)):
            para = para.strip()
            if not para:
                continue
            if size + len(para) > config.CHUNK_MAX_CHARS and current:
                chunks.append((head, "\n\n".join(current)))
                current, size = [], 0
            current.append(para)
            size += len(para)
        if current:
            chunks.append((head, "\n\n".join(current)))

    # Gộp mẩu quá ngắn vào mẩu trước cho đỡ vụn
    merged: list[tuple[str, str]] = []
    for head, body in chunks:
        if merged and len(body) < config.CHUNK_MIN_CHARS and merged[-1][0] == head:
            prev_head, prev_body = merged.pop()
            merged.append((prev_head, prev_body + "\n\n" + body))
        else:
            merged.append((head, body))
    return merged


# --------------------------------------------------------------------- embedding


def _to_blob(vector: list[float]) -> bytes:
    arr = np.asarray(vector, dtype=np.float32)
    norm = float(np.linalg.norm(arr))
    if norm > 0:
        arr = arr / norm  # chuẩn hoá sẵn -> cosine = tích vô hướng
    return arr.tobytes()


def pending_embedding_count() -> int:
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM chunks c "
            "LEFT JOIN embeddings e ON e.chunk_id = c.id WHERE e.chunk_id IS NULL"
        ).fetchone()
    finally:
        conn.close()
    return int(row["n"])


def build_embeddings(limit: int | None = None) -> int:
    """Sinh embedding cho các chunk còn thiếu. Trả về số chunk đã xử lý."""
    if not llm.available():
        return 0

    conn = get_conn()
    try:
        sql = (
            "SELECT c.id, c.heading, c.content FROM chunks c "
            "LEFT JOIN embeddings e ON e.chunk_id = c.id WHERE e.chunk_id IS NULL ORDER BY c.id"
        )
        if limit:
            sql += f" LIMIT {int(limit)}"
        rows = conn.execute(sql).fetchall()
    finally:
        conn.close()

    if not rows:
        return 0

    texts = [f"{r['heading']}\n{r['content']}".strip() for r in rows]
    vectors = llm.embed(texts)

    with tx() as conn:
        for row, vec in zip(rows, vectors):
            conn.execute(
                "INSERT OR REPLACE INTO embeddings (chunk_id, model, dim, vector) VALUES (?,?,?,?)",
                (row["id"], config.EMBED_MODEL, len(vec), _to_blob(vec)),
            )
    return len(rows)


# --------------------------------------------------------------------- truy hồi


def _fetch_chapter_chunks(conn: sqlite3.Connection, chapter_id: int) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT id, chapter_id, heading, content FROM chunks WHERE chapter_id = ? ORDER BY ord",
        (chapter_id,),
    ).fetchall()


def _tokenize(text: str) -> list[str]:
    return [t for t in (m.group(0).lower() for m in _TOKEN_RE.finditer(text)) if t not in _STOPWORDS]


def _lexical_search(rows: list[sqlite3.Row], query: str, top_k: int) -> list[Chunk]:
    """TF-IDF thô, dùng khi không có vector."""
    q_terms = set(_tokenize(query))
    if not q_terms:
        return [Chunk(r["id"], r["chapter_id"], r["heading"] or "", r["content"]) for r in rows[:top_k]]

    docs = [_tokenize(f"{r['heading']} {r['content']}") for r in rows]
    n_docs = len(docs) or 1
    df = Counter()
    for doc in docs:
        df.update(set(doc))

    scored: list[Chunk] = []
    for row, doc in zip(rows, docs):
        tf = Counter(doc)
        length = len(doc) or 1
        score = 0.0
        for term in q_terms:
            if term in tf:
                idf = math.log(1 + n_docs / (1 + df[term]))
                score += (tf[term] / length) * idf
        scored.append(Chunk(row["id"], row["chapter_id"], row["heading"] or "", row["content"], score))

    scored.sort(key=lambda c: c.score, reverse=True)
    return scored[:top_k]


def _vector_search(
    conn: sqlite3.Connection, rows: list[sqlite3.Row], query: str, top_k: int
) -> list[Chunk] | None:
    """Trả None nếu không đủ dữ liệu vector để tìm."""
    if not llm.available() or not rows:
        return None

    ids = [r["id"] for r in rows]
    placeholders = ",".join("?" * len(ids))
    emb_rows = conn.execute(
        f"SELECT chunk_id, dim, vector FROM embeddings WHERE chunk_id IN ({placeholders})", ids
    ).fetchall()
    if not emb_rows:
        return None

    try:
        q_vec = llm.embed([query])[0]
    except llm.LLMError:
        return None

    q = np.asarray(q_vec, dtype=np.float32)
    q_norm = float(np.linalg.norm(q))
    if q_norm == 0:
        return None
    q = q / q_norm

    by_id = {r["id"]: r for r in rows}
    matrix, order = [], []
    for er in emb_rows:
        vec = np.frombuffer(er["vector"], dtype=np.float32)
        if vec.shape[0] != q.shape[0]:
            continue  # embedding cũ khác model -> bỏ qua
        matrix.append(vec)
        order.append(er["chunk_id"])
    if not matrix:
        return None

    scores = np.asarray(matrix) @ q
    ranked = sorted(zip(order, scores), key=lambda x: float(x[1]), reverse=True)[:top_k]
    return [
        Chunk(
            cid,
            by_id[cid]["chapter_id"],
            by_id[cid]["heading"] or "",
            by_id[cid]["content"],
            float(score),
        )
        for cid, score in ranked
        if cid in by_id
    ]


def search(chapter_id: int, query: str, top_k: int | None = None) -> list[Chunk]:
    """Truy hồi ngữ liệu trong phạm vi một chương."""
    top_k = top_k or config.TOP_K
    conn = get_conn()
    try:
        rows = _fetch_chapter_chunks(conn, chapter_id)
        if not rows:
            return []
        hits = _vector_search(conn, rows, query, top_k)
        if hits:
            return hits
        return _lexical_search(rows, query, top_k)
    finally:
        conn.close()


def random_chunks(chapter_id: int, k: int = 2, seed: int | None = None) -> list[Chunk]:
    """Bốc ngẫu nhiên vài đoạn trong chương để làm hạt giống ra đề."""
    conn = get_conn()
    try:
        rows = _fetch_chapter_chunks(conn, chapter_id)
    finally:
        conn.close()
    if not rows:
        return []
    rnd = random.Random(seed)
    picked = rnd.sample(rows, min(k, len(rows)))
    return [Chunk(r["id"], r["chapter_id"], r["heading"] or "", r["content"]) for r in picked]


def get_chunks(chunk_ids: list[int]) -> list[Chunk]:
    if not chunk_ids:
        return []
    conn = get_conn()
    try:
        placeholders = ",".join("?" * len(chunk_ids))
        rows = conn.execute(
            f"SELECT id, chapter_id, heading, content FROM chunks WHERE id IN ({placeholders})",
            chunk_ids,
        ).fetchall()
    finally:
        conn.close()
    return [Chunk(r["id"], r["chapter_id"], r["heading"] or "", r["content"]) for r in rows]


def format_context(chunks: list[Chunk]) -> str:
    """Ghép các đoạn thành khối ngữ cảnh có đánh số nguồn cho prompt."""
    parts: list[str] = []
    for i, c in enumerate(chunks, 1):
        head = f" — {c.heading}" if c.heading else ""
        parts.append(f"[Nguồn {i}{head}]\n{c.content}")
    return "\n\n".join(parts)


def stats() -> dict[str, Any]:
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT (SELECT COUNT(*) FROM subjects) AS subjects,"
            " (SELECT COUNT(*) FROM chapters) AS chapters,"
            " (SELECT COUNT(*) FROM chunks) AS chunks,"
            " (SELECT COUNT(*) FROM embeddings) AS embeddings,"
            " (SELECT COUNT(*) FROM questions) AS questions"
        ).fetchone()
    finally:
        conn.close()
    return dict(row)
