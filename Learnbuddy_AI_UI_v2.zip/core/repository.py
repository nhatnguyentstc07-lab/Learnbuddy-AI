"""Truy vấn dữ liệu nghiệp vụ: môn học, chương, phiên tranh biện, lịch sử."""

from __future__ import annotations

import json
import random
from typing import Any

from .db import get_conn, tx

ROLE_USER_ANSWER = "user_answer"
ROLE_AI_REBUTTAL = "ai_rebuttal"
ROLE_USER_REBUTTAL = "user_rebuttal"


# ------------------------------------------------------------------ môn / chương


def list_subjects() -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT s.id, s.code, s.name, s.description, COUNT(c.id) AS chapter_count "
            "FROM subjects s LEFT JOIN chapters c ON c.subject_id = s.id "
            "GROUP BY s.id ORDER BY s.id"
        ).fetchall()
    finally:
        conn.close()
    return [dict(r) for r in rows]


def list_chapters(subject_id: int) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT ch.id, ch.code, ch.title, ch.topic, "
            "(SELECT COUNT(*) FROM chunks k WHERE k.chapter_id = ch.id) AS chunk_count, "
            "(SELECT COUNT(*) FROM questions q WHERE q.chapter_id = ch.id) AS question_count "
            "FROM chapters ch WHERE ch.subject_id = ? ORDER BY ch.ord, ch.id",
            (subject_id,),
        ).fetchall()
    finally:
        conn.close()
    return [dict(r) for r in rows]


def get_chapter(chapter_id: int) -> dict[str, Any] | None:
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT ch.id, ch.code, ch.title, ch.topic, s.name AS subject_name, "
            "s.id AS subject_id, "
            "(SELECT COUNT(*) FROM chunks k WHERE k.chapter_id = ch.id) AS chunk_count, "
            "(SELECT COUNT(*) FROM questions q WHERE q.chapter_id = ch.id) AS question_count "
            "FROM chapters ch JOIN subjects s ON s.id = ch.subject_id WHERE ch.id = ?",
            (chapter_id,),
        ).fetchone()
    finally:
        conn.close()
    return dict(row) if row else None


def chapters_missing_topic() -> list[dict[str, Any]]:
    """Các chương có câu hỏi nhưng chưa được đặt nhãn chủ đề."""
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT ch.id, ch.title, s.name AS subject_name FROM chapters ch "
            "JOIN subjects s ON s.id = ch.subject_id "
            "WHERE (ch.topic IS NULL OR ch.topic = '') "
            "AND EXISTS (SELECT 1 FROM questions q WHERE q.chapter_id = ch.id) "
            "ORDER BY ch.id"
        ).fetchall()
    finally:
        conn.close()
    return [dict(r) for r in rows]


def set_chapter_topic(chapter_id: int, topic: str) -> None:
    with tx() as conn:
        conn.execute("UPDATE chapters SET topic = ? WHERE id = ?", (topic, chapter_id))


# -------------------------------------------------------- ngân hàng câu hỏi ôn tập


def difficulty_availability(chapter_id: int) -> dict[str, int]:
    """Số câu hỏi có sẵn trong ngân hàng theo từng mức độ."""
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT difficulty, COUNT(*) AS n FROM questions WHERE chapter_id = ? "
            "GROUP BY difficulty",
            (chapter_id,),
        ).fetchall()
    finally:
        conn.close()
    return {r["difficulty"]: r["n"] for r in rows}


def pick_bank_question(
    chapter_id: int, difficulty: str, exclude: list[str] | None = None
) -> dict[str, Any] | None:
    """Bốc ngẫu nhiên một câu trong ngân hàng, ưu tiên câu chưa hỏi gần đây."""
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT id, content, source FROM questions WHERE chapter_id = ? AND difficulty = ?",
            (chapter_id, difficulty),
        ).fetchall()
    finally:
        conn.close()
    if not rows:
        return None

    excluded = set(exclude or [])
    fresh = [r for r in rows if r["content"] not in excluded]
    pool = fresh or rows  # đã hỏi hết thì cho phép lặp lại
    chosen = random.choice(pool)
    return {"id": chosen["id"], "content": chosen["content"], "source": chosen["source"]}


def chapter_question_samples(chapter_id: int, limit: int = 12) -> list[str]:
    """Danh sách câu hỏi của chương, dùng làm mô tả phạm vi chủ đề cho LLM."""
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT content FROM questions WHERE chapter_id = ? ORDER BY difficulty, ord "
            "LIMIT ?",
            (chapter_id, limit),
        ).fetchall()
    finally:
        conn.close()
    return [r["content"] for r in rows]


# ------------------------------------------------------------------------ phiên


def create_session(
    user_id: int, chapter_id: int, difficulty: str, question: str, context: str
) -> int:
    with tx() as conn:
        cur = conn.execute(
            "INSERT INTO sessions (user_id, chapter_id, difficulty, question, context) "
            "VALUES (?,?,?,?,?)",
            (user_id, chapter_id, difficulty, question, context),
        )
        return int(cur.lastrowid)


def add_turn(session_id: int, round_no: int, role: str, content: str) -> int:
    with tx() as conn:
        cur = conn.execute(
            "INSERT INTO turns (session_id, round_no, role, content) VALUES (?,?,?,?)",
            (session_id, round_no, role, content),
        )
        return int(cur.lastrowid)


def get_turns(session_id: int) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT round_no, role, content, created_at FROM turns "
            "WHERE session_id = ? ORDER BY id",
            (session_id,),
        ).fetchall()
    finally:
        conn.close()
    return [dict(r) for r in rows]


def get_session(session_id: int) -> dict[str, Any] | None:
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT se.*, ch.title AS chapter_title, s.name AS subject_name "
            "FROM sessions se JOIN chapters ch ON ch.id = se.chapter_id "
            "JOIN subjects s ON s.id = ch.subject_id WHERE se.id = ?",
            (session_id,),
        ).fetchone()
    finally:
        conn.close()
    return dict(row) if row else None


def close_session(session_id: int) -> None:
    with tx() as conn:
        conn.execute(
            "UPDATE sessions SET status = 'done', finished_at = datetime('now') WHERE id = ?",
            (session_id,),
        )


def abandon_session(session_id: int) -> None:
    with tx() as conn:
        conn.execute(
            "UPDATE sessions SET status = 'abandoned', finished_at = datetime('now') "
            "WHERE id = ? AND status = 'open'",
            (session_id,),
        )


def save_verdict(session_id: int, verdict: dict[str, Any]) -> None:
    with tx() as conn:
        conn.execute(
            "INSERT INTO verdicts (session_id, total_score, winner, payload_json) VALUES (?,?,?,?) "
            "ON CONFLICT(session_id) DO UPDATE SET total_score = excluded.total_score, "
            "winner = excluded.winner, payload_json = excluded.payload_json",
            (
                session_id,
                float(verdict.get("diem_tong", 0)),
                str(verdict.get("ben_thuyet_phuc_hon", "hoa")),
                json.dumps(verdict, ensure_ascii=False),
            ),
        )


def get_verdict(session_id: int) -> dict[str, Any] | None:
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT payload_json FROM verdicts WHERE session_id = ?", (session_id,)
        ).fetchone()
    finally:
        conn.close()
    return json.loads(row["payload_json"]) if row else None


# ---------------------------------------------------------------- lịch sử cá nhân


def history(user_id: int, limit: int = 50) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT se.id, se.difficulty, se.question, se.status, se.created_at, "
            "ch.title AS chapter_title, s.name AS subject_name, "
            "v.total_score, v.winner "
            "FROM sessions se "
            "JOIN chapters ch ON ch.id = se.chapter_id "
            "JOIN subjects s ON s.id = ch.subject_id "
            "LEFT JOIN verdicts v ON v.session_id = se.id "
            "WHERE se.user_id = ? ORDER BY se.id DESC LIMIT ?",
            (user_id, limit),
        ).fetchall()
    finally:
        conn.close()
    return [dict(r) for r in rows]


def user_stats(user_id: int) -> dict[str, Any]:
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS total, "
            "SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) AS finished "
            "FROM sessions WHERE user_id = ?",
            (user_id,),
        ).fetchone()
        avg = conn.execute(
            "SELECT AVG(v.total_score) AS avg_score FROM verdicts v "
            "JOIN sessions se ON se.id = v.session_id WHERE se.user_id = ?",
            (user_id,),
        ).fetchone()
        by_subject = conn.execute(
            "SELECT s.name AS subject_name, COUNT(*) AS n, AVG(v.total_score) AS avg_score "
            "FROM sessions se JOIN chapters ch ON ch.id = se.chapter_id "
            "JOIN subjects s ON s.id = ch.subject_id "
            "LEFT JOIN verdicts v ON v.session_id = se.id "
            "WHERE se.user_id = ? GROUP BY s.id ORDER BY n DESC",
            (user_id,),
        ).fetchall()
    finally:
        conn.close()
    return {
        "total": row["total"] or 0,
        "finished": row["finished"] or 0,
        "avg_score": avg["avg_score"],
        "by_subject": [dict(r) for r in by_subject],
    }


def recent_questions(user_id: int, chapter_id: int, limit: int = 5) -> list[str]:
    """Các câu hỏi gần đây trong cùng chương -> tránh ra trùng đề."""
    conn = get_conn()
    try:
        rows = conn.execute(
            "SELECT question FROM sessions WHERE user_id = ? AND chapter_id = ? "
            "ORDER BY id DESC LIMIT ?",
            (user_id, chapter_id, limit),
        ).fetchall()
    finally:
        conn.close()
    return [r["question"] for r in rows]
