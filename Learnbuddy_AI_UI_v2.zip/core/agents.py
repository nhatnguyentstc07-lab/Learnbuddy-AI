"""Lớp đa tác tử (multi-agent) của hệ thống.

Toàn bộ nghiệp vụ tranh biện được mô tả bằng **bốn tác tử có vai trò tách bạch**, khai
báo tường minh ở ``AGENTS`` bên dưới. Mỗi tác tử có mục tiêu riêng, bối cảnh riêng và
có thể gán model riêng — nhờ vậy thay đổi hành vi một vai không ảnh hưởng các vai khác,
và thêm vai mới chỉ cần khai thêm một ``AgentSpec``.

Có hai bộ chạy (backend), chọn bằng biến môi trường ``AGENT_FRAMEWORK``:

  * ``native`` (mặc định) — gọi thẳng OpenAI qua ``core.llm``. Nhẹ, không phụ thuộc
    thư viện ngoài, đúng bằng số lời gọi tối thiểu.
  * ``crewai``  — dựng Agent/Task/Crew của CrewAI cho từng lượt. Cùng model, cùng
    prompt, cùng số lời gọi; khác ở chỗ vai trò được framework mô hình hoá tường minh.

Dù chọn backend nào, kết quả trả về vẫn là văn bản thuần nên phần nghiệp vụ phía trên
(``core.debate``) không cần biết đang chạy bằng gì.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from . import config
from .llm import LLMError, chat, parse_json


@dataclass(frozen=True)
class AgentSpec:
    """Khai báo một tác tử: vai trò, mục tiêu và tham số sinh văn bản."""

    key: str
    name: str
    role: str
    goal: str
    backstory: str
    temperature: float | None = None
    max_tokens: int = 900
    json_output: bool = False
    model_env: str = ""  # tên biến môi trường để gán model riêng cho vai này

    @property
    def model(self) -> str:
        return config.model_for(self.model_env)


# --------------------------------------------------------------- danh bạ tác tử

QUESTION_SETTER = AgentSpec(
    key="question_setter",
    name="Người ra đề",
    role="Giảng viên ra đề ôn tập",
    goal=(
        "Chọn hoặc soạn một câu hỏi ôn tập đúng chương, đúng mức độ khó, "
        "buộc sinh viên phải suy nghĩ chứ không chỉ nhắc lại định nghĩa."
    ),
    backstory=(
        "Bạn là giảng viên nhiều năm đứng lớp, quen với việc thiết kế câu hỏi phân loại "
        "được sinh viên: câu dễ kiểm tra khái niệm nền, câu khó buộc chọn lập trường và "
        "bảo vệ nó."
    ),
    temperature=0.8,
    max_tokens=250,
    model_env="QUESTION_MODEL",
)

DEBATER = AgentSpec(
    key="debater",
    name="Người phản biện",
    role="Người phản biện học thuật",
    goal=(
        "Tìm ra lỗ hổng trong lập luận của sinh viên và chất vấn đúng chỗ yếu nhất, "
        "để họ tự nhận ra thiếu sót thay vì được cho sẵn đáp án."
    ),
    backstory=(
        "Bạn đóng vai người phản biện trong một buổi bảo vệ. Bạn không tấn công cá nhân, "
        "chỉ tấn công lập luận; bạn thích dùng phản ví dụ và tình huống biên."
    ),
    max_tokens=700,
    model_env="DEBATER_MODEL",
)

JUDGE = AgentSpec(
    key="judge",
    name="Trọng tài",
    role="Trọng tài học thuật độc lập",
    goal=(
        "Chấm điểm khách quan cả hai bên theo bốn tiêu chí, chỉ ra chỗ hổng kiến thức "
        "và gợi ý cải thiện cụ thể cho sinh viên."
    ),
    backstory=(
        "Bạn là giám khảo được mời từ ngoài, không tham gia cuộc tranh biện và không có "
        "lý do gì để bênh bên phản biện. Bạn chỉ căn cứ vào ngữ liệu môn học và những gì "
        "hai bên thực sự nói ra."
    ),
    temperature=0.2,
    max_tokens=1400,
    json_output=True,
    model_env="JUDGE_MODEL",
)

TOPIC_LABELER = AgentSpec(
    key="topic_labeler",
    name="Người đặt nhãn chương",
    role="Trợ lý biên mục học liệu",
    goal="Đặt tên chủ đề ngắn gọn cho một chương dựa trên các câu hỏi ôn tập của nó.",
    backstory="Bạn quen với việc đọc lướt một tập câu hỏi và gọi tên đúng chủ đề chung.",
    temperature=0.2,
    max_tokens=40,
    model_env="",
)

AGENTS: dict[str, AgentSpec] = {
    spec.key: spec for spec in (QUESTION_SETTER, DEBATER, JUDGE, TOPIC_LABELER)
}


# ------------------------------------------------------------------- điều phối


@dataclass
class AgentRun:
    """Kết quả một lượt chạy tác tử, kèm thông tin để hiển thị và gỡ lỗi."""

    agent: str
    backend: str
    model: str
    output: str
    data: dict[str, Any] | None = None
    meta: dict[str, Any] = field(default_factory=dict)


def active_backend() -> str:
    return config.AGENT_FRAMEWORK


def run(spec: AgentSpec, instructions: str, context: str = "") -> AgentRun:
    """Giao một nhiệm vụ cho tác tử và nhận kết quả.

    ``instructions`` là phần mô tả nhiệm vụ cụ thể của lượt này; ``context`` là dữ
    liệu kèm theo (ngữ liệu RAG, diễn biến tranh biện...). Hai backend nhận cùng một
    nội dung, chỉ khác cách bọc.
    """
    backend = active_backend()
    prompt = f"{context}\n\n{instructions}".strip() if context else instructions

    if config.offline_mode():
        # Chưa có khoá API: báo đúng một loại lỗi cho mọi backend để phần nghiệp vụ
        # phía trên chuyển sang nội dung mẫu ngoại tuyến.
        raise LLMError("OFFLINE")

    if backend == "crewai":
        from . import crew_backend  # nhập tại chỗ: chỉ cần khi thật sự bật CrewAI

        output = crew_backend.run_task(spec, prompt)
    else:
        output = chat(
            system_prompt(spec),
            prompt,
            temperature=spec.temperature,
            max_tokens=spec.max_tokens,
            json_mode=spec.json_output,
        )

    data = parse_json(output) if spec.json_output else None
    return AgentRun(
        agent=spec.key, backend=backend, model=spec.model, output=output.strip(), data=data
    )


def system_prompt(spec: AgentSpec, extra: str = "") -> str:
    """Dựng system prompt từ khai báo vai trò của tác tử."""
    parts = [
        f"Bạn là {spec.role}.",
        spec.backstory,
        f"Mục tiêu của bạn: {spec.goal}",
    ]
    if extra:
        parts.append(extra)
    return "\n".join(p for p in parts if p)


def describe() -> list[dict[str, str]]:
    """Bảng mô tả các tác tử, dùng cho giao diện và tài liệu."""
    return [
        {
            "key": spec.key,
            "name": spec.name,
            "role": spec.role,
            "goal": spec.goal,
            "model": spec.model,
            "json": "có" if spec.json_output else "không",
        }
        for spec in AGENTS.values()
    ]


__all__ = [
    "AGENTS",
    "AgentRun",
    "AgentSpec",
    "DEBATER",
    "JUDGE",
    "LLMError",
    "QUESTION_SETTER",
    "TOPIC_LABELER",
    "active_backend",
    "describe",
    "run",
    "system_prompt",
]
