"""Đọc file .docx ngân hàng câu hỏi ôn tập (không cần thư viện ngoài).

Định dạng dữ liệu thật rất lộn xộn: nhiều câu hỏi bị dồn chung một đoạn, tiêu đề
chương dính liền câu hỏi cuối của chương trước, có lỗi OCR (CẦU HỎI / CÂU HỒI /
HƯỚNG DĂN), lẫn số trang và ký tự rác. Vì vậy bộ phân tích không dựa vào ranh giới
đoạn văn mà quét toàn văn bằng ba loại mốc: tiêu đề chương, nhãn nhóm độ khó và
mốc "Câu hỏi N.".
"""

from __future__ import annotations

import re
import unicodedata
import zipfile
from xml.etree import ElementTree
from dataclasses import dataclass, field
from pathlib import Path

# --- mốc nhận dạng, viết lỏng để chịu được lỗi OCR --------------------------------


# Một file có thể chứa nhiều học phần nối tiếp nhau; mỗi mốc dưới đây mở đầu một môn
_RE_SUBJECT = re.compile(r"H[ọo]c\s+ph[ầâa]n\s*\d*\s*[:.]\s*(.+?)\s*$", re.M | re.I)
_RE_TOC = re.compile(r"^\s*Ch[ưu][ơo]ng\s+(\d+)\s*[:.]\s*(.+?)\s*$", re.M | re.I)
_RE_CHAPTER = re.compile(
    r"\d+(?:\.\d+)*\.\s*C[ÂẦA]U\s*H[ỎỒÔO]I[^\n]{0,80}?CH[ƯU][ƠO]NG\s*(\d+)",
    re.I,
)
_RE_GROUP = re.compile(r"Nh[óo]m\s+c[âa]u\s+h[ỏo]i\s*(d[ễe]|trung\s*b[ìi]nh|kh[óo])\s*:?", re.I)
# Mốc câu hỏi, viết lỏng để nhận cả "Câu hỏi 1.", "Câu 1:", "Câu 3 :", "Câu 4 ;"
_RE_QUESTION = re.compile(r"C[âầấa]u\s*(?:h[ỏồốo]i)?\s*(\d+)\s*[.:;]")
# Dòng phương án của câu trắc nghiệm: "A. ...", "B) ..."
_RE_OPTION = re.compile(r"^[A-Da-d][.)]\s+\S")
# Mốc phương án nằm lẫn giữa dòng (đề bài và phương án A bị dồn chung một đoạn)
_RE_INLINE_OPTION = re.compile(r"\s+(?=[A-D][.)]\s)")

_DIFFICULTY_MAP = {"de": "easy", "trungbinh": "medium", "kho": "hard"}

_XML_ENTITIES = {"&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&apos;": "'"}


@dataclass
class ParsedChapter:
    number: int
    title: str
    questions: dict[str, list[str]] = field(default_factory=dict)

    @property
    def total(self) -> int:
        return sum(len(v) for v in self.questions.values())


@dataclass
class ParsedSubject:
    name: str
    code: str
    source: str
    chapters: list[ParsedChapter] = field(default_factory=list)

    @property
    def total_questions(self) -> int:
        return sum(c.total for c in self.chapters)


# ------------------------------------------------------------------ tiện ích chuỗi


def strip_accents(text: str) -> str:
    decomposed = unicodedata.normalize("NFD", text.replace("đ", "d").replace("Đ", "D"))
    return "".join(ch for ch in decomposed if unicodedata.category(ch) != "Mn")


def make_code(name: str, max_len: int = 24) -> str:
    ascii_name = strip_accents(name).upper()
    code = re.sub(r"[^A-Z0-9]+", "_", ascii_name).strip("_")
    return code[:max_len] or "SUBJECT"


def _norm_difficulty(label: str) -> str:
    key = re.sub(r"[^a-z]", "", strip_accents(label).lower())
    return _DIFFICULTY_MAP.get(key, "medium")


def _unescape(text: str) -> str:
    for entity, char in _XML_ENTITIES.items():
        text = text.replace(entity, char)
    return text


# --------------------------------------------------------------------- đọc docx


_W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def extract_paragraphs(path: Path) -> list[str]:
    """Lấy danh sách đoạn văn bản thuần từ file .docx.

    Dùng bộ phân tích XML thay vì regex: nhiều file thật có đoạn lồng nhau (khung
    văn bản, nội dung thay thế của Word), khiến cách cắt bằng biểu thức chính quy
    lấy nhầm cả thẻ XML vào phần văn bản.
    """
    with zipfile.ZipFile(path) as archive:
        data = archive.read("word/document.xml")

    root = ElementTree.fromstring(data)
    paragraphs: list[str] = []
    for para in root.iter(f"{_W_NS}p"):
        pieces: list[str] = []
        for node in para.iter():
            tag = node.tag
            if tag == f"{_W_NS}t":
                pieces.append(node.text or "")
            elif tag in (f"{_W_NS}tab", f"{_W_NS}br", f"{_W_NS}cr"):
                pieces.append(" ")
        text = "".join(pieces).replace("\xa0", " ")
        text = re.sub(r"\s+", " ", text).strip()
        if text:
            paragraphs.append(text)
    return paragraphs


# ------------------------------------------------------------------- làm sạch câu


def _normalise_options(lines: list[str]) -> list[str]:
    """Chỉnh lại các phương án của một câu trắc nghiệm.

    Sửa hai kiểu hỏng thường gặp trong tài liệu thật:
      - phương án A bị dồn chung dòng với đề bài -> tách ra dòng riêng;
      - phương án của câu khác lạc sang (chữ cái không tăng dần, ví dụ A B C rồi
        lại C D) -> cắt bỏ từ chỗ lạc trở đi.
    """
    first = next((i for i, line in enumerate(lines) if _RE_OPTION.match(line)), None)
    if first is None:
        return lines

    head: list[str] = []
    for line in lines[:first]:
        head.extend(part.strip() for part in _RE_INLINE_OPTION.split(line) if part.strip())

    out: list[str] = []
    last = ""
    for line in head + lines[first:]:
        if _RE_OPTION.match(line):
            letter = line[0].upper()
            if letter <= last:
                break  # đã sang phương án của câu khác
            last = letter
        out.append(line)
    return out


def _clean_question(text: str) -> str:
    """Làm sạch một câu hỏi.

    Câu trắc nghiệm được giữ nguyên bố cục nhiều dòng (mỗi phương án một dòng);
    câu tự luận thì gộp về một dòng như trước.
    """
    lines = [
        re.sub(r"\s+", " ", line.replace("|", " ")).strip(" \t-–—•")
        for line in text.split("\n")
    ]
    lines = [line for line in lines if line]
    if not lines:
        return ""

    if any(_RE_OPTION.match(line) for line in lines):
        lines = _normalise_options(lines)
        # Số trang chỉ có thể lẫn vào dòng đề bài, không lẫn vào phương án
        lines[0] = re.sub(r"[\s.]*\b\d{2,3}\b\s*$", "", lines[0]).strip()
        return "\n".join(line for line in lines if line)

    merged = " ".join(lines)
    # Số trang lọt vào cuối câu (ví dụ "... của sự kiện pháp lý? 102")
    merged = re.sub(r"[\s.]*\b\d{1,3}\b\s*$", "", merged).strip()
    # Bỏ phần đuôi cụt sau dấu hỏi cuối cùng nếu nó quá ngắn để là một ý trọn vẹn
    last_q = merged.rfind("?")
    if last_q != -1 and len(merged) - last_q - 1 < 12:
        merged = merged[: last_q + 1]
    return merged.strip()


def _split_questions(segment: str) -> list[str]:
    """Tách một khối văn bản (thuộc cùng chương, cùng mức độ) thành các câu hỏi.

    Hai kiểu trình bày đều gặp trong tài liệu thật:
      - có đánh số: "Câu hỏi 1." / "Câu 1:" -> cắt theo mốc.
      - không đánh số: mỗi đoạn văn là một câu -> cắt theo dòng, riêng các dòng
        phương án trắc nghiệm thì gắn vào câu ngay trước.
    """
    marks = list(_RE_QUESTION.finditer(segment))
    if marks:
        parts: list[str] = []
        for i, mark in enumerate(marks):
            stop = marks[i + 1].start() if i + 1 < len(marks) else len(segment)
            parts.append(segment[mark.end() : stop])
        return parts

    parts = []
    for line in segment.split("\n"):
        line = line.strip()
        if not line:
            continue
        if parts and _RE_OPTION.match(line):
            parts[-1] += "\n" + line
        else:
            parts.append(line)
    return parts


# --------------------------------------------------------------------- phân tích


def parse_subject_block(full_text: str, name: str, source: str) -> ParsedSubject:
    """Phân tích phần văn bản của MỘT học phần thành chương → nhóm độ khó."""
    name = re.sub(r"\s+", " ", name).strip(" .:-")

    toc = {int(no): title.strip() for no, title in _RE_TOC.findall(full_text)}
    max_chapter = max(toc) if toc else 99

    # Chỉ dùng hai loại mốc để chia văn bản thành các vùng "chương + mức độ";
    # việc tách câu hỏi bên trong mỗi vùng do _split_questions lo, vì mỗi tài liệu
    # trình bày câu hỏi một kiểu khác nhau.
    markers: list[tuple[int, int, str, str]] = []
    for m in _RE_CHAPTER.finditer(full_text):
        digits = m.group(1)
        # "CHƯƠNG 21.3.1." -> số chương thật là 2, phần còn lại là số mục
        while len(digits) > 1 and int(digits) > max_chapter:
            digits = digits[:-1]
        markers.append((m.start(), m.end(), "chapter", digits))
    for m in _RE_GROUP.finditer(full_text):
        markers.append((m.start(), m.end(), "group", m.group(1)))
    markers.sort()

    chapters: dict[int, ParsedChapter] = {}
    current_chapter: int | None = None
    current_difficulty = "medium"

    for index, (_start, end, kind, value) in enumerate(markers):
        if kind == "chapter":
            current_chapter = int(value)
            current_difficulty = "medium"
            chapters.setdefault(
                current_chapter,
                ParsedChapter(current_chapter, toc.get(current_chapter, f"Chương {value}")),
            )
            continue

        current_difficulty = _norm_difficulty(value)
        if current_chapter is None:
            continue

        stop = markers[index + 1][0] if index + 1 < len(markers) else len(full_text)
        chapter = chapters[current_chapter]
        bucket = chapter.questions.setdefault(current_difficulty, [])
        for raw in _split_questions(full_text[end:stop]):
            body = _clean_question(raw)
            if len(body) < 15 or body in bucket:
                continue
            bucket.append(body)

    ordered = [chapters[k] for k in sorted(chapters)]
    # Bổ sung các chương có trong mục lục nhưng không có câu hỏi nào
    for no in sorted(toc):
        if no not in chapters:
            ordered.append(ParsedChapter(no, toc[no]))
    ordered.sort(key=lambda c: c.number)

    return ParsedSubject(name=name, code=make_code(name), source=source, chapters=ordered)


def parse_docx(path: Path) -> list[ParsedSubject]:
    """Phân tích một file .docx thành danh sách học phần.

    Tài liệu thật có khi gộp nhiều học phần vào chung một file (ví dụ phần "Học
    phần 2" và "Học phần 3" nối tiếp nhau), nên hàm này trả về danh sách chứ
    không phải một môn duy nhất.
    """
    full_text = "\n".join(extract_paragraphs(path))
    blocks = list(_RE_SUBJECT.finditer(full_text))

    if not blocks:
        subject = parse_subject_block(full_text, name=path.stem, source=path.name)
        return [subject] if subject.total_questions else []

    subjects: list[ParsedSubject] = []
    for i, block in enumerate(blocks):
        end = blocks[i + 1].start() if i + 1 < len(blocks) else len(full_text)
        subject = parse_subject_block(
            full_text[block.end() : end], name=block.group(1), source=path.name
        )
        if subject.total_questions:
            subjects.append(subject)
    return subjects
