# Chương 2 — Học máy có giám sát

## Đặt bài toán

Học có giám sát tìm một hàm ánh xạ f: X → Y từ tập dữ liệu đã gán nhãn {(xᵢ, yᵢ)}. Nếu Y rời rạc, ta có bài toán phân loại; nếu Y liên tục, ta có hồi quy. Giả định nền tảng thường bị bỏ quên: dữ liệu huấn luyện và dữ liệu triển khai phải cùng phân phối và độc lập (i.i.d.). Khi giả định này vỡ — do dịch chuyển phân phối theo thời gian, hoặc do cách lấy mẫu thiên lệch — mô hình có thể đạt độ chính xác cao trên tập kiểm tra nhưng thất bại trong vận hành thực tế.

Định lý "không có bữa trưa miễn phí" phát biểu rằng khi lấy trung bình trên mọi bài toán có thể có, không thuật toán nào tốt hơn thuật toán nào. Hệ quả thực tiễn: mọi thuật toán đều mang một thiên kiến quy nạp (inductive bias), và việc chọn mô hình thực chất là chọn thiên kiến phù hợp với cấu trúc của bài toán cụ thể.

## Một số họ mô hình

**Hồi quy tuyến tính** cực tiểu tổng bình phương sai số. Nhạy với điểm ngoại lai vì sai số bị bình phương, và giả định quan hệ tuyến tính giữa đặc trưng với đầu ra.

**Hồi quy logistic** là mô hình phân loại chứ không phải hồi quy, dù tên gọi dễ gây nhầm. Nó áp hàm sigmoid lên tổ hợp tuyến tính để cho ra xác suất, huấn luyện bằng cực đại hoá hàm hợp lý (tương đương cực tiểu hoá cross-entropy). Biên quyết định vẫn là siêu phẳng — mô hình tuyến tính trong không gian đặc trưng.

**k-NN** không có pha huấn luyện thật sự, chỉ lưu dữ liệu và tra cứu khi dự đoán. Đơn giản nhưng tốn bộ nhớ, dự đoán chậm khi dữ liệu lớn, và suy thoái nghiêm trọng ở số chiều cao do lời nguyền chiều: trong không gian nhiều chiều, khoảng cách giữa điểm gần nhất và xa nhất trở nên gần như bằng nhau, khiến khái niệm "láng giềng" mất ý nghĩa. Bắt buộc phải chuẩn hoá thang đo đặc trưng, nếu không đặc trưng có đơn vị lớn sẽ chi phối khoảng cách.

**Cây quyết định** chia không gian bằng các câu hỏi theo từng đặc trưng, chọn điểm chia theo Gini hoặc entropy. Ưu điểm lớn nhất là dễ diễn giải và không cần chuẩn hoá dữ liệu. Nhược điểm là phương sai cao: chỉ cần thay đổi vài mẫu huấn luyện, cấu trúc cây có thể khác hẳn. Rừng ngẫu nhiên khắc phục bằng cách lấy trung bình nhiều cây huấn luyện trên các mẫu bootstrap và tập con đặc trưng ngẫu nhiên — giảm phương sai mạnh, nhưng đánh mất phần lớn khả năng diễn giải.

**SVM** tìm siêu phẳng cực đại hoá lề giữa hai lớp; thủ thuật hạt nhân cho phép phân tách phi tuyến mà không cần tính tường minh không gian đặc trưng mở rộng. Hiệu quả với dữ liệu ít mẫu, nhiều chiều, nhưng chi phí huấn luyện tăng nhanh theo số mẫu và việc chọn hạt nhân cùng siêu tham số C, γ rất nhạy.

## Đánh đổi độ chệch – phương sai

Sai số kỳ vọng của mô hình phân rã thành ba phần: độ chệch bình phương, phương sai và nhiễu không thể loại bỏ. Mô hình quá đơn giản có độ chệch cao (chưa khớp, underfitting); mô hình quá phức tạp có phương sai cao (quá khớp, overfitting). Chỉ có hai thành phần đầu là điều chỉnh được; thành phần nhiễu đặt ra trần hiệu năng mà không thuật toán nào vượt qua được — nên mục tiêu "độ chính xác 100%" thường là dấu hiệu của rò rỉ dữ liệu chứ không phải mô hình giỏi.

Đáng chú ý, đường cong "chữ U" cổ điển của đánh đổi độ chệch – phương sai không mô tả đầy đủ các mạng nơ-ron rất lớn: hiện tượng double descent cho thấy khi số tham số vượt xa số mẫu, sai số kiểm tra có thể giảm trở lại. Đây là lĩnh vực còn đang tranh luận, không nên áp dụng máy móc lý thuyết cổ điển cho mọi mô hình.

## Chính quy hoá và kỹ thuật đặc trưng

Chính quy hoá L2 (ridge) co các trọng số về gần 0 nhưng hiếm khi bằng 0; L1 (lasso) tạo nghiệm thưa, tự động chọn đặc trưng. Với mạng nơ-ron còn có dropout, dừng sớm và tăng cường dữ liệu.

Chất lượng đặc trưng thường quyết định kết quả nhiều hơn việc chọn thuật toán. Cần đặc biệt chú ý rò rỉ dữ liệu (data leakage): nếu chuẩn hoá dữ liệu hoặc chọn đặc trưng bằng thống kê tính trên toàn bộ tập, thông tin từ tập kiểm tra đã lọt vào quá trình huấn luyện, khiến điểm đánh giá cao giả tạo. Mọi phép biến đổi phải được học từ tập huấn luyện rồi mới áp lên tập kiểm tra — đó là lý do pipeline tồn tại.

## Dữ liệu mất cân bằng

Với dữ liệu 99% lớp âm, một mô hình luôn đoán "âm" đạt 99% độ chính xác mà hoàn toàn vô dụng. Các hướng xử lý: lấy mẫu lại (oversampling lớp thiểu số, ví dụ SMOTE; hoặc undersampling lớp đa số), đặt trọng số lớp trong hàm mất mát, và quan trọng nhất là đổi thước đo sang precision, recall, F1 hoặc PR-AUC. Lưu ý kỹ thuật: việc lấy mẫu lại chỉ được thực hiện trên tập huấn luyện — nếu áp lên tập kiểm tra, kết quả đánh giá không còn phản ánh phân phối thực tế.
