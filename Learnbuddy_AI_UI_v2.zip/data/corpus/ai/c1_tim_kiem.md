# Chương 1 — Thuật toán tìm kiếm

## Bài toán tìm kiếm trong không gian trạng thái

Một bài toán tìm kiếm được đặc tả bởi: trạng thái đầu, tập hành động khả dĩ, hàm chuyển trạng thái, kiểm tra đích và hàm chi phí đường đi. Lời giải là một dãy hành động dẫn từ trạng thái đầu tới trạng thái đích; lời giải tối ưu là lời giải có chi phí thấp nhất.

Bốn tiêu chí đánh giá thuật toán: tính đầy đủ (có tìm được lời giải khi lời giải tồn tại không), tính tối ưu (lời giải tìm được có tốt nhất không), độ phức tạp thời gian và độ phức tạp không gian. Trong thực tế, bộ nhớ thường là ràng buộc chặt hơn thời gian — đây là lý do các thuật toán tối ưu về lý thuyết như BFS hay A* lại thất bại trên bài toán lớn.

## Tìm kiếm mù

**BFS** duyệt theo từng mức, dùng hàng đợi. Nó đầy đủ và tối ưu khi mọi bước có chi phí bằng nhau, nhưng cả thời gian lẫn bộ nhớ đều là O(b^d) với b là hệ số phân nhánh và d là độ sâu lời giải. Bộ nhớ mới là điểm chết: với b = 10, d = 12, số nút cần lưu vượt xa khả năng của máy tính thông thường.

**DFS** dùng ngăn xếp, chỉ tốn bộ nhớ O(b·m) với m là độ sâu tối đa. Đổi lại nó không đầy đủ trong không gian vô hạn hoặc có chu trình, và không tối ưu.

**Tìm kiếm chi phí đồng nhất (UCS)** mở rộng nút có chi phí đường đi g(n) nhỏ nhất; đây chính là Dijkstra đặt trong khung tìm kiếm, đầy đủ và tối ưu với chi phí bước không âm.

**Tìm kiếm sâu dần (IDS)** lặp DFS với giới hạn độ sâu tăng dần. Nghe có vẻ lãng phí vì lặp lại công việc, nhưng vì số nút ở mức cuối chiếm phần lớn tổng số nút trong cây phân nhánh, chi phí thừa chỉ khoảng vài chục phần trăm. IDS đạt được ưu điểm bộ nhớ của DFS và tính tối ưu của BFS — thường là lựa chọn tốt nhất trong nhóm tìm kiếm mù.

## Tìm kiếm có thông tin và A*

Tìm kiếm tham lam theo hàm heuristic chọn nút có h(n) nhỏ nhất. Nó nhanh nhưng không tối ưu và có thể lạc hướng hoàn toàn.

**A\*** dùng f(n) = g(n) + h(n), kết hợp chi phí đã đi và ước lượng chi phí còn lại.

- A* là tối ưu khi h **chấp nhận được** (admissible): không bao giờ đánh giá cao hơn chi phí thực tế còn lại. Điều kiện này áp dụng cho tìm kiếm trên cây.
- Với tìm kiếm trên đồ thị (có loại nút đã duyệt), cần điều kiện mạnh hơn là **nhất quán** (consistent): h(n) ≤ c(n, n') + h(n') với mọi cạnh. Nhất quán kéo theo chấp nhận được, nhưng chiều ngược lại không đúng. Bỏ qua khác biệt này là lỗi hay gặp: dùng heuristic chỉ chấp nhận được trong graph search có thể cho lời giải không tối ưu.

A* mở rộng số nút ít nhất trong các thuật toán tối ưu dùng cùng heuristic, nhưng nó vẫn phải giữ toàn bộ tập nút mở và đóng trong bộ nhớ, nên thường hết RAM trước khi hết thời gian. Các biến thể IDA*, SMA* hoặc beam search đánh đổi tính tối ưu để giảm bộ nhớ.

Chất lượng heuristic quyết định hiệu năng: heuristic h₂ **trội** hơn h₁ nếu h₂(n) ≥ h₁(n) với mọi n mà vẫn chấp nhận được; khi đó A* với h₂ không bao giờ mở rộng nhiều nút hơn. Heuristic thường được sinh ra bằng cách nới lỏng ràng buộc bài toán — ví dụ khoảng cách Manhattan trong bài toán 8-puzzle là chi phí chính xác của bài toán đã nới lỏng, cho phép quân trượt qua nhau.

## Tìm kiếm cục bộ

Khi chỉ cần trạng thái đích chứ không cần đường đi (xếp lịch, tối ưu tham số), tìm kiếm cục bộ giữ một hoặc vài trạng thái hiện tại và cải thiện dần. Leo đồi đơn giản và tốn rất ít bộ nhớ, nhưng kẹt ở cực đại địa phương, cao nguyên phẳng và sườn núi. Mô phỏng luyện kim chấp nhận bước xấu với xác suất giảm dần theo nhiệt độ; về lý thuyết, nếu nhiệt độ giảm đủ chậm nó hội tụ tới cực trị toàn cục với xác suất tiến tới 1 — nhưng "đủ chậm" trong thực tế thường chậm hơn cả duyệt vét cạn, nên đây là bảo đảm lý thuyết ít giá trị vận hành. Thuật toán di truyền duy trì một quần thể và lai ghép; nó linh hoạt nhưng không có bảo đảm nào về tính tối ưu và rất nhạy với cách mã hoá lời giải.

## Trò chơi đối kháng

Minimax giả định cả hai bên chơi tối ưu, độ phức tạp O(b^m) khiến nó bất khả thi với cờ vua. Cắt tỉa alpha-beta cho cùng kết quả nhưng bỏ qua các nhánh không thể ảnh hưởng tới quyết định; với thứ tự nút lý tưởng, độ phức tạp giảm còn O(b^(m/2)), tức nhân đôi độ sâu tìm kiếm được trong cùng thời gian. Quan trọng: alpha-beta **không** thay đổi kết quả, chỉ thay đổi số nút phải xét — nên nói "alpha-beta cho nước đi kém chính xác hơn minimax" là sai. Trong thực tế, cây quá lớn nên phải cắt ở độ sâu giới hạn và dùng hàm đánh giá, chính hàm đánh giá xấp xỉ này mới là nguồn sai lệch.
