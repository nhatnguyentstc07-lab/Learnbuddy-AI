# Chương 3 — Đánh giá mô hình và quá khớp

## Vì sao phải tách dữ liệu

Sai số trên tập huấn luyện là ước lượng lạc quan có hệ thống cho hiệu năng thực. Do đó dữ liệu được chia ba phần: tập huấn luyện để học tham số, tập thẩm định (validation) để chọn siêu tham số và so sánh mô hình, tập kiểm tra (test) chỉ dùng đúng một lần ở cuối để báo cáo. Nếu dùng tập kiểm tra nhiều lần để tinh chỉnh, nó biến thành tập thẩm định trên thực tế và con số báo cáo mất giá trị — hiện tượng quá khớp lên tập kiểm tra do lặp lại thí nghiệm quá nhiều lần.

Kiểm định chéo k-fold chia dữ liệu thành k phần, luân phiên mỗi phần làm tập thẩm định, rồi lấy trung bình. Nó cho ước lượng ổn định hơn khi dữ liệu ít, đổi lại chi phí huấn luyện gấp k lần. Với dữ liệu mất cân bằng cần dùng stratified k-fold để giữ tỷ lệ lớp trong mỗi fold.

Với dữ liệu chuỗi thời gian, kiểm định chéo ngẫu nhiên là **sai về nguyên tắc**: nó cho phép mô hình học từ tương lai để dự đoán quá khứ. Phải dùng chia theo thời gian hoặc kiểm định chéo tiến dần (rolling/expanding window). Tương tự, khi dữ liệu có nhóm (nhiều ảnh của cùng một bệnh nhân), phải chia theo nhóm, nếu không cùng một cá thể xuất hiện ở cả hai bên và điểm số bị thổi phồng.

## Ma trận nhầm lẫn và các thước đo

Với phân loại nhị phân, ma trận nhầm lẫn gồm TP, FP, TN, FN.

- **Accuracy** = (TP+TN)/tổng. Gây hiểu lầm nghiêm trọng khi dữ liệu mất cân bằng.
- **Precision** = TP/(TP+FP): trong số dự đoán dương, bao nhiêu phần thực sự đúng. Quan trọng khi báo động giả gây tốn kém.
- **Recall** = TP/(TP+FN): trong số ca dương thực tế, bắt được bao nhiêu. Quan trọng khi bỏ sót gây hậu quả nặng, như sàng lọc ung thư.
- **F1** là trung bình điều hoà của precision và recall; nó phạt nặng khi một trong hai quá thấp, khác với trung bình cộng.

Precision và recall đánh đổi lẫn nhau qua ngưỡng quyết định: hạ ngưỡng làm tăng recall, giảm precision. Vì vậy so sánh hai mô hình ở hai ngưỡng khác nhau là so sánh khập khiễng. Điểm mấu chốt: **ngưỡng là một quyết định nghiệp vụ**, phụ thuộc chi phí tương đối của FP và FN, không phải hằng số 0.5 mặc định.

## ROC-AUC và PR-AUC

ROC vẽ TPR theo FPR khi ngưỡng biến thiên; AUC là xác suất mô hình xếp một mẫu dương ngẫu nhiên cao hơn một mẫu âm ngẫu nhiên. Vì ROC không phụ thuộc tỷ lệ lớp nên nó có thể trông rất đẹp ngay cả khi mô hình vô dụng trên dữ liệu cực kỳ mất cân bằng: FPR có mẫu số là số ca âm khổng lồ, nên hàng nghìn báo động giả cũng chỉ làm FPR nhích lên chút ít. Trong tình huống đó, đường cong precision–recall và PR-AUC phản ánh trung thực hơn.

## Chẩn đoán quá khớp và chưa khớp

Dấu hiệu quá khớp: sai số huấn luyện rất thấp trong khi sai số thẩm định cao và khoảng cách giữa hai đường ngày càng rộng. Dấu hiệu chưa khớp: cả hai đều cao và hội tụ về nhau ở mức tệ.

Đường cong học (learning curve) theo kích thước dữ liệu giúp phân biệt: nếu hai đường còn cách xa và đường thẩm định vẫn đang giảm, thu thập thêm dữ liệu sẽ có ích; nếu hai đường đã chạm nhau ở mức sai số cao, thêm dữ liệu gần như vô ích và cần mô hình phức tạp hơn hoặc đặc trưng tốt hơn. Đây là lý do câu trả lời "cứ thêm dữ liệu" không phải lúc nào cũng đúng.

Các biện pháp chống quá khớp: chính quy hoá, dừng sớm, giảm độ phức tạp mô hình, tăng cường dữ liệu, và học tập hợp (ensemble).

## Ý nghĩa thống kê và bẫy diễn giải

Chênh lệch 0,3 điểm phần trăm giữa hai mô hình trên một tập kiểm tra vài trăm mẫu thường nằm trong dao động ngẫu nhiên. Cần báo cáo khoảng tin cậy (ví dụ bằng bootstrap) hoặc kiểm định trên nhiều lần chạy với hạt giống ngẫu nhiên khác nhau, thay vì kết luận từ một con số đơn lẻ.

Cuối cùng, mọi thước đo tổng hợp đều che giấu sự khác biệt giữa các nhóm con. Một mô hình đạt F1 = 0,90 tổng thể vẫn có thể hoạt động rất kém trên một nhóm thiểu số. Đánh giá theo lát cắt (slice-based evaluation) và kiểm tra công bằng là phần bắt buộc trước khi đưa mô hình vào vận hành, không phải việc làm thêm nếu còn thời gian.
