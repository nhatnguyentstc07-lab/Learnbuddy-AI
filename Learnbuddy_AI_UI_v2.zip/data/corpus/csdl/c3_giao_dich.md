# Chương 3 — Giao dịch và điều khiển đồng thời

## Giao dịch và tính chất ACID

Giao dịch (transaction) là một đơn vị công việc logic gồm nhiều thao tác, hoặc thực hiện trọn vẹn, hoặc không để lại dấu vết nào. Bốn tính chất ACID:

- **Atomicity (nguyên tử)**: mọi thao tác thành công hết, hoặc bị hoàn tác (rollback) hết. Do nhật ký undo và cơ chế khôi phục bảo đảm.
- **Consistency (nhất quán)**: giao dịch đưa CSDL từ trạng thái hợp lệ này sang trạng thái hợp lệ khác. Đây là tính chất được chia sẻ trách nhiệm: hệ quản trị kiểm tra ràng buộc đã khai báo, còn tính đúng đắn nghiệp vụ vẫn thuộc về lập trình viên.
- **Isolation (cô lập)**: các giao dịch chạy đồng thời cho kết quả như thể chúng chạy tuần tự. Đây là tính chất thường bị hy sinh một phần để đổi lấy hiệu năng.
- **Durability (bền vững)**: khi đã COMMIT, dữ liệu tồn tại kể cả khi hệ thống sập, nhờ ghi nhật ký xuống đĩa trước.

## Các hiện tượng bất thường khi chạy đồng thời

- **Dirty read**: đọc dữ liệu mà một giao dịch khác đã ghi nhưng chưa commit; nếu giao dịch đó rollback, giá trị vừa đọc chưa từng tồn tại hợp lệ.
- **Non-repeatable read**: đọc cùng một dòng hai lần trong một giao dịch cho hai giá trị khác nhau vì giao dịch khác đã sửa và commit ở giữa.
- **Phantom read**: chạy lại cùng một truy vấn theo điều kiện lọc thì thấy xuất hiện thêm (hoặc bớt) dòng, do giao dịch khác chèn/xoá dòng thoả điều kiện.
- **Lost update**: hai giao dịch cùng đọc rồi cùng ghi đè, kết quả của một bên biến mất.

## Mức cô lập

Chuẩn SQL định nghĩa bốn mức: READ UNCOMMITTED, READ COMMITTED, REPEATABLE READ và SERIALIZABLE. Mức càng cao càng ngăn được nhiều bất thường nhưng càng giảm mức độ song song. Lưu ý quan trọng: chuẩn SQL định nghĩa mức cô lập theo *các bất thường bị cấm*, nên cách hiện thực khác nhau giữa các hệ quản trị. PostgreSQL không có READ UNCOMMITTED thật (nó hành xử như READ COMMITTED). REPEATABLE READ của InnoDB dùng đọc nhất quán ảnh chụp nên chặn được cả phantom trong phần lớn tình huống, khác với mô tả trong chuẩn. Vì thế nói "REPEATABLE READ luôn cho phép phantom" là phát biểu đúng theo chuẩn nhưng sai với nhiều hệ thống thực tế.

## Khả tuần tự và giao thức khoá

Một lịch biểu (schedule) được gọi là khả tuần tự theo xung đột (conflict-serializable) nếu có thể hoán vị các thao tác không xung đột để biến nó thành một lịch tuần tự. Hai thao tác xung đột khi cùng truy cập một mục dữ liệu, thuộc hai giao dịch khác nhau, và ít nhất một là ghi. Công cụ kiểm tra là đồ thị ưu tiên: lịch biểu khả tuần tự theo xung đột khi và chỉ khi đồ thị không có chu trình.

Giao thức khoá hai pha (2PL) chia mỗi giao dịch thành pha mở rộng (chỉ xin khoá) và pha thu hẹp (chỉ nhả khoá). 2PL bảo đảm khả tuần tự nhưng không bảo đảm tránh được deadlock, cũng không tránh được rollback dây chuyền. Biến thể 2PL nghiêm ngặt (strict 2PL) giữ mọi khoá ghi tới khi kết thúc giao dịch, nhờ đó tránh rollback dây chuyền và là lựa chọn phổ biến trong thực tế — cái giá là thời gian giữ khoá dài hơn.

Deadlock được xử lý theo hai hướng: phát hiện (dựng đồ thị chờ, tìm chu trình rồi chọn nạn nhân để huỷ) hoặc phòng tránh (sắp thứ tự tài nguyên, dùng lược đồ wait-die / wound-wait dựa trên nhãn thời gian). Không có phương án nào miễn phí: phát hiện tốn chi phí giám sát và gây huỷ giao dịch, còn phòng tránh làm giảm mức song song.

## MVCC — điều khiển đồng thời đa phiên bản

MVCC lưu nhiều phiên bản của một dòng. Giao dịch đọc nhìn thấy ảnh chụp nhất quán tại thời điểm bắt đầu, nhờ đó **đọc không chặn ghi và ghi không chặn đọc** — ưu thế lớn so với khoá thuần tuý. Cái giá phải trả là chi phí lưu trữ phiên bản cũ và nhu cầu dọn rác (VACUUM trong PostgreSQL, undo log trong InnoDB). MVCC cũng không tự động loại bỏ mọi bất thường: ở mức snapshot isolation vẫn có thể xảy ra write skew, khi hai giao dịch đọc cùng một tập dữ liệu rồi ghi vào hai dòng khác nhau, khiến một ràng buộc liên dòng bị vi phạm dù từng giao dịch riêng lẻ đều hợp lệ. Xử lý triệt để cần Serializable Snapshot Isolation hoặc khoá tường minh.

## Khôi phục sau sự cố

Nguyên tắc WAL (Write-Ahead Logging) yêu cầu bản ghi nhật ký phải xuống đĩa trước khi trang dữ liệu tương ứng được ghi. Thuật toán ARIES khôi phục theo ba pha: phân tích (xác định trạng thái tại thời điểm sập), làm lại (redo mọi thay đổi đã ghi log để đưa hệ thống về đúng trạng thái trước sự cố, kể cả của giao dịch chưa commit) và hoàn tác (undo các giao dịch chưa commit). Điểm kiểm tra (checkpoint) giúp rút ngắn pha phân tích và làm lại. Việc redo cả giao dịch chưa commit khiến nhiều sinh viên bất ngờ, nhưng đó là hệ quả tất yếu của chiến lược "repeating history" nhằm khôi phục đúng cấu trúc trang dữ liệu trước khi undo.
