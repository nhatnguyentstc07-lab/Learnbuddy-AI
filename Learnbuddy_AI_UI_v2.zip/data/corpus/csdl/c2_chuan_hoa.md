# Chương 2 — Phụ thuộc hàm và chuẩn hoá

## Phụ thuộc hàm

Cho lược đồ quan hệ R với hai tập thuộc tính X và Y. Ta nói X xác định hàm Y, ký hiệu X → Y, nếu với mọi thể hiện hợp lệ của R, hai bộ bất kỳ trùng nhau trên X thì cũng phải trùng nhau trên Y. Điểm mấu chốt: phụ thuộc hàm là ràng buộc **ngữ nghĩa** của bài toán, không phải điều suy ra được từ dữ liệu đang có. Việc quan sát một bảng mẫu rồi kết luận "X → Y" chỉ cho ta giả thuyết; dữ liệu tương lai có thể bác bỏ nó.

Hệ tiên đề Armstrong gồm ba luật: phản xạ (nếu Y ⊆ X thì X → Y), tăng trưởng (nếu X → Y thì XZ → YZ) và bắc cầu (nếu X → Y và Y → Z thì X → Z). Từ đó suy ra các luật dẫn xuất: hợp, tách, giả bắc cầu. Hệ này vừa đúng đắn (sound) vừa đầy đủ (complete): mọi phụ thuộc hàm suy diễn logic được đều dẫn ra được bằng ba luật trên.

Bao đóng X⁺ là tập mọi thuộc tính mà X xác định được. Thuật toán tính bao đóng chạy trong thời gian đa thức và là công cụ chính để kiểm tra một tập thuộc tính có phải khoá hay không: X là siêu khoá khi và chỉ khi X⁺ chứa toàn bộ thuộc tính của R.

## Các dị thường khi thiết kế kém

Một lược đồ chưa chuẩn hoá sinh ra ba loại dị thường: dị thường cập nhật (sửa một dữ kiện phải sửa nhiều dòng, dễ gây mâu thuẫn), dị thường chèn (không thể ghi nhận thông tin về một thực thể vì thiếu thực thể khác), và dị thường xoá (xoá dòng cuối cùng làm mất luôn một dữ kiện độc lập). Nguyên nhân chung là một quan hệ đang mô tả nhiều loại sự vật cùng lúc.

## Các dạng chuẩn

- **1NF**: mọi giá trị thuộc tính đều nguyên tố, không có nhóm lặp hay danh sách trong một ô.
- **2NF**: đạt 1NF và không có thuộc tính không khoá nào phụ thuộc hàm bộ phận vào một khoá dự tuyển. Vấn đề này chỉ phát sinh khi khoá gồm nhiều thuộc tính; nếu mọi khoá dự tuyển đều đơn thuộc tính thì lược đồ 1NF tự động đạt 2NF.
- **3NF**: đạt 2NF và không có thuộc tính không khoá nào phụ thuộc bắc cầu vào khoá. Phát biểu tương đương: với mọi phụ thuộc hàm X → A không tầm thường, hoặc X là siêu khoá, hoặc A là thuộc tính khoá (thuộc một khoá dự tuyển nào đó).
- **BCNF**: với mọi phụ thuộc hàm X → A không tầm thường, X phải là siêu khoá. BCNF chặt hơn 3NF đúng ở chỗ nó bỏ mất ngoại lệ "A là thuộc tính khoá".

## Đánh đổi cốt lõi: BCNF và bảo toàn phụ thuộc

Mọi lược đồ đều tách được về 3NF vừa bảo toàn thông tin (lossless join) vừa bảo toàn phụ thuộc hàm. Nhưng với BCNF, chỉ bảo đảm được tách bảo toàn thông tin; **không phải lúc nào cũng tồn tại phép tách BCNF bảo toàn phụ thuộc**. Ví dụ kinh điển là quan hệ (Sinh viên, Môn học, Giảng viên) với hai ràng buộc: mỗi giảng viên chỉ dạy một môn (GV → Môn), và mỗi sinh viên trong một môn chỉ học với một giảng viên (SV, Môn → GV). Lược đồ này ở 3NF nhưng không ở BCNF; mọi cách tách về BCNF đều làm mất khả năng kiểm tra ràng buộc (SV, Môn → GV) bằng một bảng đơn lẻ.

Do đó câu hỏi "chuẩn càng cao càng tốt" là sai. Thực tế người thiết kế phải cân nhắc: dừng ở 3NF để giữ được ràng buộc, hay lên BCNF để triệt tiêu dư thừa nhưng phải kiểm tra ràng buộc bằng trigger hoặc mã ứng dụng — vốn tốn kém và dễ sai.

## Phụ thuộc đa trị và 4NF

Phụ thuộc đa trị X ↠ Y xuất hiện khi một thực thể có hai tập thuộc tính độc lập nhau, ví dụ một nhân viên có nhiều kỹ năng và nhiều ngôn ngữ, hai danh sách không liên quan. Lưu chung trong một bảng buộc phải sinh tích Descartes giữa hai danh sách, gây dư thừa mà 3NF/BCNF không phát hiện. 4NF yêu cầu mọi phụ thuộc đa trị không tầm thường đều có vế trái là siêu khoá. 5NF (dạng chuẩn nối) xử lý trường hợp quan hệ chỉ tách được thành ba bảng trở lên mà không mất thông tin — hiếm gặp trong thực tế.

## Phi chuẩn hoá có kiểm soát

Trong hệ thống thiên về đọc (báo cáo, kho dữ liệu), nhiều nhóm cố ý phi chuẩn hoá: nhân bản cột, lưu giá trị đã tổng hợp sẵn, gộp bảng để tránh join. Đổi lại, họ phải tự chịu trách nhiệm giữ nhất quán bằng trigger, job đồng bộ hoặc chấp nhận nhất quán cuối (eventual consistency). Đây là quyết định kỹ thuật có điều kiện, không phải lý do để bỏ qua chuẩn hoá ngay từ khâu thiết kế khái niệm: phi chuẩn hoá đúng đắn đòi hỏi trước hết phải biết lược đồ chuẩn hoá trông như thế nào.
