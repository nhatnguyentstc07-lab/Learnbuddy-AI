# Chương 1 — Mô hình quan hệ và đại số quan hệ

## Khái niệm nền tảng của mô hình quan hệ

Mô hình quan hệ do E. F. Codd đề xuất năm 1970, biểu diễn dữ liệu bằng các quan hệ (relation), trực quan là các bảng hai chiều. Mỗi quan hệ gồm một tập thuộc tính (cột) và một tập bộ (tuple, tức dòng). Điểm cốt lõi thường bị hiểu sai: quan hệ trong lý thuyết là một **tập hợp**, nên về nguyên tắc không có thứ tự dòng và không có dòng trùng lặp. Trong khi đó, bảng của SQL thực chất là một **đa tập** (multiset/bag): SQL cho phép dòng trùng nhau nếu không khai báo khoá, và `SELECT` không đảm bảo thứ tự khi thiếu `ORDER BY`. Đây là khác biệt lý thuyết – thực hành mà sinh viên hay bỏ qua.

Lược đồ quan hệ (schema) mô tả cấu trúc: tên quan hệ, danh sách thuộc tính cùng miền giá trị (domain) của chúng. Thể hiện (instance) là dữ liệu cụ thể tại một thời điểm. Miền giá trị phải nguyên tố (atomic) theo yêu cầu của dạng chuẩn 1 — nghĩa là một ô không chứa danh sách hay cấu trúc lồng nhau.

## Khoá và các ràng buộc toàn vẹn

Siêu khoá (superkey) là tập thuộc tính xác định duy nhất mỗi bộ. Khoá dự tuyển (candidate key) là siêu khoá tối tiểu, tức bỏ đi bất kỳ thuộc tính nào cũng mất tính duy nhất. Khoá chính (primary key) là một khoá dự tuyển được chọn làm đại diện. Một quan hệ có thể có nhiều khoá dự tuyển nhưng chỉ một khoá chính.

Ba loại ràng buộc toàn vẹn quan trọng:

- **Toàn vẹn miền**: giá trị thuộc tính phải nằm trong miền đã khai báo.
- **Toàn vẹn thực thể**: thuộc tính thuộc khoá chính không được nhận giá trị NULL.
- **Toàn vẹn tham chiếu**: giá trị khoá ngoại phải tồn tại ở quan hệ được tham chiếu, hoặc bằng NULL.

Khi xoá/cập nhật bản ghi cha, hệ quản trị áp dụng chính sách CASCADE, SET NULL, SET DEFAULT hoặc RESTRICT/NO ACTION. Lựa chọn CASCADE tiện lợi nhưng nguy hiểm: một lệnh xoá tưởng như nhỏ có thể lan truyền và xoá lượng lớn dữ liệu ở nhiều bảng con.

## Giá trị NULL và logic ba trị

NULL không phải số 0, cũng không phải chuỗi rỗng; nó biểu thị "chưa biết" hoặc "không áp dụng". Hệ quả là SQL dùng logic ba trị: TRUE, FALSE và UNKNOWN. Biểu thức `NULL = NULL` trả về UNKNOWN chứ không phải TRUE, nên phải dùng `IS NULL`. Mệnh đề `WHERE` chỉ giữ lại dòng có điều kiện TRUE, do đó dòng cho kết quả UNKNOWN bị loại. Ngược lại, các hàm gộp như `COUNT(cot)` bỏ qua NULL, còn `COUNT(*)` thì không — đây là nguồn sai lệch số liệu rất phổ biến trong báo cáo.

## Đại số quan hệ

Đại số quan hệ là ngôn ngữ thủ tục (procedural), mô tả *cách* lấy dữ liệu qua một dãy phép toán. Năm phép toán cơ sở gồm: chọn (σ), chiếu (π), tích Descartes (×), hợp (∪) và hiệu (−). Các phép khác như giao (∩), kết nối (⋈), chia (÷) đều dẫn xuất được từ nhóm cơ sở.

- **Chọn σ** lọc theo dòng; **chiếu π** lọc theo cột. Phép chiếu trong đại số quan hệ tự động loại bỏ trùng lặp vì kết quả phải là tập hợp, còn `SELECT` của SQL thì không, trừ khi viết `SELECT DISTINCT`.
- **Kết nối tự nhiên (natural join)** ghép hai quan hệ trên các thuộc tính cùng tên và loại bỏ cột trùng. Nếu hai quan hệ không có thuộc tính chung, kết nối tự nhiên suy biến thành tích Descartes — một bẫy thường gặp.
- **Kết nối ngoài (outer join)** giữ lại các bộ không tìm được bộ đối ứng, điền NULL vào phần thiếu. Đây là lý do outer join hay sinh ra NULL và kéo theo các vấn đề của logic ba trị.
- **Phép chia (÷)** dùng cho truy vấn dạng "tìm các đối tượng liên quan tới *tất cả* phần tử của một tập", ví dụ "sinh viên đã học tất cả môn bắt buộc".

## Đại số quan hệ, phép tính quan hệ và SQL

Phép tính quan hệ (relational calculus) là ngôn ngữ phi thủ tục: chỉ mô tả *cái gì* cần lấy, không nói cách lấy. Định lý về tính đầy đủ quan hệ khẳng định đại số quan hệ và phép tính quan hệ (dạng an toàn) có sức biểu diễn tương đương. SQL đứng ở giữa: cú pháp mang tính mô tả, nhưng bộ tối ưu hoá truy vấn bên trong sẽ dịch câu lệnh thành một cây các phép toán đại số quan hệ rồi chọn kế hoạch thi hành rẻ nhất. Vì vậy, hiểu đại số quan hệ giúp giải thích được vì sao hai câu SQL cho cùng kết quả lại có hiệu năng chênh nhau hàng chục lần.

Một điểm gây tranh luận: đại số quan hệ cơ sở **không** biểu diễn được phép gộp (aggregation), sắp xếp hay truy vấn đệ quy. Các mở rộng như đại số quan hệ mở rộng mới bổ sung toán tử gộp và nhóm. Do đó không thể nói SQL chỉ là "lớp vỏ cú pháp" của đại số quan hệ cổ điển.
