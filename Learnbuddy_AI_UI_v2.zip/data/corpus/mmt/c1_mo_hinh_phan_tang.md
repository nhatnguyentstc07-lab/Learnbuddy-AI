# Chương 1 — Mô hình OSI và TCP/IP

## Vì sao phải phân tầng

Kiến trúc phân tầng chia bài toán truyền thông thành các lớp có trách nhiệm rõ ràng, mỗi lớp chỉ dùng dịch vụ của lớp ngay dưới và cung cấp dịch vụ cho lớp ngay trên. Lợi ích là tính mô-đun: thay đổi công nghệ đường truyền không buộc phải viết lại ứng dụng. Cái giá phải trả gồm chi phí đóng gói lặp lại ở mỗi tầng (header chồng header), và hiện tượng lặp chức năng — ví dụ kiểm soát lỗi xuất hiện ở cả tầng liên kết dữ liệu lẫn tầng giao vận.

Nguyên lý end-to-end lập luận rằng một chức năng chỉ nên đặt ở tầng thấp khi nó giúp tối ưu hiệu năng, còn tính đúng đắn cuối cùng phải do hai đầu cuối bảo đảm. Truyền lại ở tầng liên kết dữ liệu của Wi-Fi là ví dụ hợp lý: nó không thay thế được TCP, nhưng giảm đáng kể số lần TCP phải truyền lại trên đường truyền nhiễu.

## Bảy tầng OSI

1. **Vật lý**: truyền bit thô, quy định điện áp, đầu nối, mã đường truyền.
2. **Liên kết dữ liệu**: đóng khung, địa chỉ MAC, phát hiện lỗi bằng CRC, điều khiển truy nhập môi trường.
3. **Mạng**: địa chỉ logic (IP), định tuyến giữa các mạng, phân mảnh gói.
4. **Giao vận**: truyền dữ liệu giữa hai tiến trình, phân kênh theo cổng, kiểm soát lỗi và luồng đầu cuối.
5. **Phiên**: thiết lập, duy trì, đồng bộ phiên làm việc.
6. **Trình diễn**: mã hoá ký tự, nén, mã hoá bảo mật.
7. **Ứng dụng**: giao thức phục vụ trực tiếp ứng dụng như HTTP, SMTP, DNS.

## Chồng giao thức TCP/IP

Mô hình TCP/IP có bốn tầng: Truy nhập mạng, Liên mạng (IP), Giao vận (TCP/UDP) và Ứng dụng. Nó gộp ba tầng trên cùng của OSI vào một tầng Ứng dụng, và gộp hai tầng dưới cùng vào tầng Truy nhập mạng.

Khác biệt bản chất không nằm ở số tầng mà ở lịch sử: OSI được thiết kế trước rồi mới có hiện thực, còn TCP/IP là mô hình mô tả lại các giao thức đã chạy được trên thực tế. Vì vậy OSI ngày nay chủ yếu là công cụ giảng dạy và mô tả, còn Internet chạy trên TCP/IP. Nói OSI "thất bại" cũng không hoàn toàn đúng — thuật ngữ và cách chia tầng của nó vẫn là ngôn ngữ chung của ngành.

## Đóng gói và mô hình đồng hồ cát

Dữ liệu đi xuống mỗi tầng lại được bọc thêm header, tạo thành các đơn vị dữ liệu khác nhau: segment (giao vận), packet/datagram (mạng), frame (liên kết dữ liệu). Ở đầu nhận, quá trình diễn ra ngược lại.

Kiến trúc Internet có hình đồng hồ cát: rất nhiều giao thức ứng dụng ở trên, rất nhiều công nghệ đường truyền ở dưới, nhưng thắt lại ở duy nhất một giao thức IP ở giữa. Chính điểm thắt này tạo nên tính phổ quát, đồng thời khiến việc thay đổi tầng mạng trở nên cực kỳ khó khăn — lý do IPv6 mất hơn hai thập kỷ vẫn chưa thay thế hoàn toàn IPv4.

## Ranh giới tầng bị phá vỡ trong thực tế

Mô hình phân tầng lý tưởng bị vi phạm thường xuyên:

- **NAT** đọc và sửa cổng TCP/UDP (tầng 4) trong khi về danh nghĩa là thiết bị tầng 3, phá vỡ mô hình end-to-end.
- **Tường lửa và bộ cân bằng tải lớp 7** ra quyết định dựa trên nội dung HTTP.
- **QUIC** đưa chức năng của tầng giao vận và bảo mật lên chạy trên UDP trong không gian người dùng, để tránh việc các thiết bị trung gian đã "hoá thạch" hành vi của TCP.

Đây là bằng chứng cho thấy phân tầng là công cụ tư duy hữu ích chứ không phải mô tả chính xác các hệ thống đang vận hành.

## Vấn đề đóng gói dữ liệu và MTU

Mỗi tầng có giới hạn kích thước đơn vị truyền tối đa (MTU); Ethernet phổ biến là 1500 byte. Khi gói IP lớn hơn MTU của chặng kế tiếp, IPv4 cho phép router phân mảnh, còn IPv6 thì không — router chỉ báo lỗi ICMP và bên gửi phải tự điều chỉnh bằng Path MTU Discovery. Thiết kế của IPv6 nhằm giảm gánh nặng cho router, nhưng phụ thuộc vào việc thông điệp ICMP đến được nơi cần đến. Nhiều quản trị viên chặn toàn bộ ICMP vì lý do an ninh, dẫn tới sự cố "PMTU đen": kết nối bắt tay thành công nhưng treo khi truyền dữ liệu lớn.
