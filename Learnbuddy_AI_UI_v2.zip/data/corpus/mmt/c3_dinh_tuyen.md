# Chương 3 — Tầng mạng và định tuyến IP

## Địa chỉ IP và chia mạng con

Địa chỉ IPv4 dài 32 bit, chia thành phần mạng và phần máy theo mặt nạ mạng. Kỹ thuật CIDR bỏ hệ thống lớp A/B/C cứng nhắc, cho phép độ dài tiền tố tuỳ ý (ví dụ 192.168.10.0/26) và gộp tuyến (route aggregation) để giảm kích thước bảng định tuyến toàn cầu. Với tiền tố /n trong IPv4, số địa chỉ là 2^(32−n), trong đó địa chỉ đầu là địa chỉ mạng và địa chỉ cuối là quảng bá, nên số máy gán được là 2^(32−n) − 2. Ngoại lệ: /31 dùng cho liên kết điểm–điểm và /32 cho một máy đơn.

IPv6 dùng 128 bit, không có quảng bá, bỏ phân mảnh tại router và cho phép tự cấu hình địa chỉ không trạng thái (SLAAC). Trở ngại của quá trình chuyển đổi phần lớn mang tính kinh tế và quán tính hệ thống, không phải kỹ thuật: NAT đã che đi sự khan hiếm địa chỉ IPv4 đủ tốt để trì hoãn nhu cầu nâng cấp.

## Chuyển tiếp và định tuyến

Cần phân biệt hai khái niệm. **Chuyển tiếp (forwarding)** là hành động cục bộ, diễn ra theo từng gói: tra bảng và đẩy gói ra cổng ra tương ứng, ở thang thời gian nano giây. **Định tuyến (routing)** là quá trình toàn mạng, chạy các giao thức để xây nên bảng đó, ở thang thời gian giây tới phút. Kiến trúc SDN đẩy sự phân tách này tới cùng: mặt phẳng điều khiển được tập trung hoá vào bộ điều khiển, còn thiết bị chỉ giữ mặt phẳng dữ liệu.

Khi tra bảng, router áp dụng nguyên tắc **khớp tiền tố dài nhất**: nếu địa chỉ đích khớp nhiều mục, chọn mục có tiền tố dài nhất (cụ thể nhất), bất kể thứ tự trong bảng hay giao thức sinh ra nó. Tuyến mặc định 0.0.0.0/0 vì thế luôn là lựa chọn cuối cùng.

## Vector khoảng cách và trạng thái liên kết

**Vector khoảng cách** (RIP): mỗi router chỉ biết láng giềng, định kỳ trao đổi toàn bộ bảng của mình và cập nhật theo phương trình Bellman–Ford. Ưu điểm là đơn giản, tốn ít bộ nhớ. Nhược điểm nghiêm trọng là hội tụ chậm và bài toán "đếm tới vô cùng": khi một tuyến hỏng, thông tin sai lan truyền vòng quanh làm khoảng cách tăng dần từng bước. Các biện pháp giảm nhẹ gồm split horizon, poison reverse, triggered update và đặt vô cùng bằng 16 — đều là vá lỗi chứ không giải quyết tận gốc.

**Trạng thái liên kết** (OSPF): mỗi router quảng bá trạng thái các liên kết của mình cho toàn vùng, mọi router dựng bản đồ mạng giống nhau rồi tự chạy Dijkstra để tính đường ngắn nhất. Ưu điểm là hội tụ nhanh, không bị đếm tới vô cùng. Nhược điểm là tốn CPU và bộ nhớ, và độ phức tạp tăng nhanh theo quy mô — nên OSPF phải chia vùng (area) với vùng backbone 0 làm trục.

## Định tuyến nội miền và liên miền

OSPF và IS-IS là giao thức nội miền: mục tiêu là tìm đường tốt nhất theo chi phí kỹ thuật trong một hệ tự trị (AS) do một tổ chức quản lý. BGP là giao thức liên miền giữa các AS, và mục tiêu của nó khác hẳn: thực thi **chính sách**. Một nhà mạng thường ưu tiên tuyến qua khách hàng của mình hơn tuyến ngắn hơn về mặt kỹ thuật vì lý do doanh thu. Do đó nói "BGP tìm đường ngắn nhất" là hiểu sai bản chất: BGP chọn theo chuỗi thuộc tính (LOCAL_PREF trước, rồi mới tới độ dài AS_PATH), và AS_PATH cũng chỉ đếm số AS chứ không phản ánh độ trễ hay băng thông thực tế.

BGP tin tưởng thông tin do láng giềng công bố, nên một AS công bố nhầm hoặc cố ý công bố tiền tố không thuộc về mình có thể hút lưu lượng của cả một vùng — hiện tượng chiếm quyền định tuyến (route hijacking). RPKI và ROV được triển khai để ký xác thực quyền sở hữu tiền tố, nhưng mức phủ vẫn chưa đủ để loại bỏ rủi ro.

## NAT: giải pháp và tranh cãi

NAT ánh xạ nhiều địa chỉ riêng ra một địa chỉ công cộng, dùng cổng để phân biệt phiên. Nó kéo dài tuổi thọ IPv4 và tình cờ tạo ra một lớp che chắn cho mạng nội bộ. Nhưng NAT phá vỡ nguyên lý end-to-end, gây khó cho các ứng dụng ngang hàng (phải dùng STUN/TURN/ICE để xuyên NAT), làm phức tạp việc ghi nhật ký truy vết, và không nên bị coi là biện pháp an ninh — nó không lọc nội dung, không thay thế được tường lửa.
