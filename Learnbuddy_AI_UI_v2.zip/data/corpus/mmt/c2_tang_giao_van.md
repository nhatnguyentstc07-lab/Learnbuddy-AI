# Chương 2 — Tầng giao vận: TCP và UDP

## Nhiệm vụ của tầng giao vận

Tầng giao vận cung cấp truyền thông logic giữa hai *tiến trình*, trong khi tầng mạng chỉ cung cấp truyền thông giữa hai *máy*. Cơ chế then chốt là phân kênh (multiplexing) và gộp kênh nhờ số hiệu cổng. Một kết nối TCP được định danh bằng bộ bốn: IP nguồn, cổng nguồn, IP đích, cổng đích. Do đó một máy chủ web chỉ mở duy nhất cổng 80 vẫn phục vụ được hàng vạn kết nối đồng thời — quan niệm "mỗi kết nối cần một cổng riêng ở phía máy chủ" là sai.

## UDP

UDP chỉ bổ sung cổng và checksum lên trên IP. Nó không thiết lập kết nối, không đảm bảo thứ tự, không truyền lại, không kiểm soát tắc nghẽn. Đổi lại: độ trễ thấp, header chỉ 8 byte, không có hiện tượng chặn đầu hàng (head-of-line blocking), và ứng dụng toàn quyền quyết định làm gì khi mất gói.

Vì vậy UDP được chọn cho DNS, thoại/hội nghị truyền hình thời gian thực, game trực tuyến và QUIC. Với truyền hình trực tiếp, một gói âm thanh đến trễ 2 giây là vô dụng — bỏ qua còn tốt hơn truyền lại. Lập luận "UDP không tin cậy nên kém hơn TCP" bỏ qua điểm mấu chốt: độ tin cậy có ích hay không phụ thuộc vào yêu cầu ứng dụng.

## TCP: kết nối và truyền tin cậy

TCP thiết lập kết nối bằng bắt tay ba bước (SYN, SYN-ACK, ACK) để đồng bộ số thứ tự khởi đầu của hai chiều. Việc dùng ba bước thay vì hai là để tránh nhận nhầm gói SYN cũ bị trễ trong mạng.

Độ tin cậy dựa trên: số thứ tự theo byte, biên nhận tích luỹ (cumulative ACK), bộ đệm sắp xếp lại và truyền lại. TCP truyền lại trong hai tình huống: hết thời gian chờ (RTO, tính theo RTT làm trơn cùng độ lệch), hoặc nhận ba ACK trùng lặp — dấu hiệu gói bị mất trong khi các gói sau vẫn tới nơi, kích hoạt truyền lại nhanh mà không cần chờ hết giờ.

Đóng kết nối cần bốn bước vì TCP song công: mỗi chiều đóng độc lập. Trạng thái TIME_WAIT kéo dài 2×MSL ở bên chủ động đóng nhằm bảo đảm ACK cuối tới nơi và tránh gói cũ lẫn vào kết nối mới trùng bộ bốn. Nhiều người coi TIME_WAIT là lỗi cấu hình và tìm cách tắt; thực tế đó là cơ chế an toàn, việc vô hiệu hoá tuỳ tiện có thể gây hỏng dữ liệu.

## Kiểm soát luồng và kiểm soát tắc nghẽn

Đây là hai cơ chế khác nhau, rất hay bị nhầm:

- **Kiểm soát luồng** bảo vệ *bên nhận* khỏi bị tràn bộ đệm, dùng cửa sổ nhận quảng bá trong mỗi ACK.
- **Kiểm soát tắc nghẽn** bảo vệ *mạng* khỏi quá tải, dựa trên cửa sổ tắc nghẽn do bên gửi tự ước lượng.

Lượng dữ liệu được phép gửi chưa nhận ACK là giá trị nhỏ nhất giữa hai cửa sổ.

Kiểm soát tắc nghẽn cổ điển (Reno/NewReno) gồm: khởi động chậm (cửa sổ tăng theo cấp số nhân cho tới ngưỡng), tránh tắc nghẽn (tăng tuyến tính), và phản ứng khi mất gói (giảm nửa cửa sổ với ba ACK trùng, hoặc về 1 MSS khi hết giờ). Mô hình này giả định **mất gói đồng nghĩa với tắc nghẽn** — giả định đúng trên mạng có dây nhưng sai trên mạng không dây, nơi gói mất chủ yếu do nhiễu. Đó là lý do TCP truyền thống cho thông lượng kém trên liên kết di động.

CUBIC (mặc định trên Linux) tăng cửa sổ theo hàm bậc ba nhằm tận dụng đường truyền băng thông lớn, độ trễ cao. BBR đi theo hướng khác hẳn: ước lượng trực tiếp băng thông khả dụng và RTT tối thiểu thay vì coi mất gói là tín hiệu, nhờ đó tránh được hiện tượng bufferbloat khi hàng đợi ở router quá lớn. Tuy nhiên BBR bị phê phán là chiếm băng thông không công bằng khi chạy chung với luồng CUBIC.

## Head-of-line blocking và động lực của QUIC

TCP giao dữ liệu theo đúng thứ tự byte, nên một gói mất sẽ chặn việc giao mọi dữ liệu đến sau, dù chúng đã nằm sẵn trong bộ đệm. Với HTTP/2 ghép nhiều luồng trên một kết nối TCP, mất một gói của luồng A làm đình trệ cả các luồng B, C — nghịch lý là HTTP/2 giải quyết chặn đầu hàng ở tầng ứng dụng nhưng lại gặp đúng vấn đề đó ở tầng giao vận. QUIC chạy trên UDP, quản lý thứ tự độc lập cho từng luồng, tích hợp sẵn TLS 1.3 nên bắt tay chỉ mất 1 RTT (0 RTT nếu nối lại), và cho phép di chuyển kết nối giữa các mạng nhờ định danh kết nối thay vì bộ bốn địa chỉ.
