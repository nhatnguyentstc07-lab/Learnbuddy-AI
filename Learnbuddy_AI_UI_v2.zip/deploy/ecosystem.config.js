// Cau hinh PM2 cho ung dung Streamlit.
//
//   cd /root/debate                       (hoac /home/ubuntu/debate)
//   pm2 start deploy/ecosystem.config.js
//   pm2 save
//   pm2 startup                           -> chay tiep lenh ma no in ra
//
// Doi "cwd" ben duoi cho khop thu muc that cua du an.

module.exports = {
  apps: [
    {
      name: "debate",

      // Chay thang file nhi phan trong venv. Bat buoc co interpreter "none",
      // neu khong PM2 se tuong day la script Node va bao loi cu phap.
      script: "./.venv/bin/streamlit",
      interpreter: "none",
      cwd: "/root/debate",

      args: [
        "run",
        "app.py",
        "--server.port=8501",
        "--server.address=0.0.0.0",
        "--server.headless=true",
        "--server.fileWatcherType=none",
        "--browser.gatherUsageStats=false",
      ].join(" "),

      // KHONG bat watch. Ung dung ghi lien tuc vao data/app.db (SQLite che do WAL),
      // bat watch se lam PM2 khoi dong lai vo tan.
      watch: false,

      autorestart: true,
      restart_delay: 5000,
      max_restarts: 10,
      kill_timeout: 20000,

      time: true, // gan moc thoi gian vao log
      merge_logs: true,
    },
  ],
};
