# Triển khai lên máy chủ Ubuntu (tài khoản `ubuntu`)

Hướng dẫn cho Ubuntu Server 22.04 / 24.04, đăng nhập bằng tài khoản `ubuntu` có quyền
`sudo` (mặc định của EC2, Lightsail, DigitalOcean, Azure...).

**Cách triển khai chính ở đây: chạy thẳng Streamlit theo IP, không cần nginx.**
Ứng dụng chạy nền bằng systemd hoặc PM2, truy cập tại `http://<IP máy chủ>:8501`.

Nếu về sau cần tên miền hoặc HTTPS bằng Let's Encrypt, xem [phụ lục ở cuối](#phụ-lục--đặt-nginx-phía-trước-tuỳ-chọn).

Thư mục đích: `/home/ubuntu/debate`

## 0. Chuẩn bị

Cần có:

- Địa chỉ IP máy chủ và khoá SSH (ví dụ `~/.ssh/debate.pem`)
- `OPENAI_API_KEY`
- Tên miền trỏ về máy chủ (không bắt buộc, nhưng cần nếu muốn HTTPS)

Đặt sẵn biến cho tiện copy lệnh (chạy trên máy Windows, PowerShell):

```powershell
$SRV = "ubuntu@203.0.113.10"       # đổi thành IP máy chủ của bạn
$KEY = "$HOME\.ssh\debate.pem"     # đổi thành đường dẫn khoá SSH
```

## 1. Cài gói hệ thống

```bash
ssh -i $KEY $SRV        # từ PowerShell
```

Trên máy chủ:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3 python3-venv python3-pip sqlite3 rsync
python3 --version       # cần >= 3.10
```

> Không cần cài `nginx` cho cách triển khai này.

## 2. Đưa mã nguồn lên

Chạy trên **Windows PowerShell**, tại thư mục dự án:

```powershell
cd d:\Data\Projects\claude\tam\debate

# Tạo thư mục đích
ssh -i $KEY $SRV "mkdir -p /home/ubuntu/debate"

# Chép mã nguồn + tài liệu, bỏ qua thứ không cần
scp -i $KEY -r app.py bootstrap_data.py smoke_test.py ui_test.py `
    requirements.txt README.md core data input deploy `
    ${SRV}:/home/ubuntu/debate/
```

Nếu máy chủ đã có `rsync` và bạn muốn đồng bộ lại nhiều lần (nhanh hơn nhiều):

```powershell
rsync -avz -e "ssh -i $KEY" `
  --exclude '.venv' --exclude '__pycache__' --exclude '.env' `
  --exclude 'data/app.db*' `
  ./ ${SRV}:/home/ubuntu/debate/
```

> **Không chép `.env`** — khoá API sẽ được tạo riêng trên máy chủ ở bước 4.
> **Không chép `.venv`** — môi trường ảo của Windows không chạy được trên Linux.

## 3. Tạo môi trường ảo và cài phụ thuộc

Trên máy chủ:

```bash
cd /home/ubuntu/debate
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
```

> **Không cài `requirements-crewai.txt` trên máy chủ** trừ khi thật sự cần. Bộ chạy
> CrewAI kéo theo khoảng 94 gói (~1,5–2 GB, có `chromadb` và `onnxruntime`) — quá nặng
> cho VPS nano và không đổi kết quả, vì cả hai bộ chạy dùng chung một model. Giữ
> `AGENT_FRAMEWORK=native` là đủ.

## 4. Tạo file `.env`

```bash
cd /home/ubuntu/debate
cp .env.example .env 2>/dev/null || cat > .env <<'EOF'
OPENAI_API_KEY=
CHAT_MODEL=gpt-4o-mini
EMBED_MODEL=text-embedding-3-small
TOP_K=4
MAX_ROUNDS=3
LLM_TEMPERATURE=0.4
SESSION_TTL_DAYS=7
EOF

nano .env               # điền OPENAI_API_KEY
chmod 600 .env          # chỉ chủ sở hữu đọc được
```

## 5. Nạp dữ liệu và xây chỉ mục

Chọn **một** trong hai cách.

### Cách A — chép sẵn CSDL từ máy Windows (khuyến nghị)

Giữ nguyên embedding và nhãn chủ đề đã tạo, máy chủ không tốn thêm lời gọi API.

Trên Windows, tạo bản sao sạch (gộp cả WAL, an toàn kể cả khi app đang chạy):

```powershell
python -c "import sqlite3; c=sqlite3.connect('data/app.db'); c.execute('VACUUM INTO \"data/app-deploy.db\"'); c.close()"
scp -i $KEY data\app-deploy.db ${SRV}:/home/ubuntu/debate/data/app.db
del data\app-deploy.db
```

### Cách B — dựng lại trên máy chủ

```bash
cd /home/ubuntu/debate
.venv/bin/python bootstrap_data.py
```

Lệnh này nạp `data/corpus`, ngân hàng câu hỏi `.docx` và giáo trình `.pdf` trong
`input/`, tạo embedding rồi đặt nhãn chủ đề cho các chương. Với bộ dữ liệu hiện tại
(692 đoạn) mất khoảng 20 giây và vài trăm đồng tiền embedding.

Chạy lại lệnh này **mỗi khi thêm tài liệu mới** vào `input/`.

## 6. Chạy thử bằng tay

```bash
cd /home/ubuntu/debate
.venv/bin/streamlit run app.py --server.port=8501 --server.address=0.0.0.0 --server.headless=true
```

Nếu chưa mở cổng ra ngoài thì kiểm tra ngay trên máy chủ:

```bash
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8501/     # mong đợi 200
```

Xong thì `Ctrl+C` và chuyển sang chạy nền ở bước 7. Việc mở cổng làm ở bước 8.

## 7. Chạy nền

Chọn **một** trong hai: systemd (có sẵn trên Ubuntu) hoặc PM2 (nếu máy chủ của bạn đã
dùng PM2 cho các ứng dụng khác).

### Cách A — systemd

```bash
sudo cp /home/ubuntu/debate/deploy/debate.service /etc/systemd/system/debate.service
sudo systemctl daemon-reload
sudo systemctl enable --now debate
sudo systemctl status debate --no-pager
```

Dịch vụ chạy dưới tài khoản `ubuntu`, tự khởi động lại khi lỗi và tự bật lại sau khi
máy chủ reboot. Xem log:

```bash
journalctl -u debate -f
```

> Nếu dự án của bạn nằm ở `/root/debate` và chạy bằng root, phải sửa file service:
>
> ```bash
> sed -i 's#/home/ubuntu/debate#/root/debate#g; s#^User=ubuntu#User=root#; \
>   s#^Group=ubuntu#Group=root#; s#^ProtectHome=read-only#ProtectHome=false#' \
>   /etc/systemd/system/debate.service
> systemctl daemon-reload && systemctl restart debate
> ```
>
> Dòng `ProtectHome` bắt buộc phải đổi: để `read-only` thì `/root` bị gắn chỉ-đọc,
> SQLite không ghi được và app báo `attempt to write a readonly database`.

### Cách B — PM2

Sửa `cwd` trong [ecosystem.config.js](ecosystem.config.js) cho khớp thư mục thật, rồi:

```bash
cd /root/debate          # hoặc /home/ubuntu/debate
pm2 start deploy/ecosystem.config.js
pm2 save
pm2 startup              # chạy tiếp đúng dòng lệnh mà nó in ra
```

Hoặc khởi động bằng một lệnh, không cần file cấu hình:

```bash
cd /root/debate
pm2 start .venv/bin/streamlit --name debate --interpreter none -- \
  run app.py --server.port=8501 --server.address=0.0.0.0 \
  --server.headless=true --server.fileWatcherType=none --browser.gatherUsageStats=false
pm2 save
```

Ba điểm dễ sai với PM2:

- **`--interpreter none`** là bắt buộc. Thiếu nó, PM2 tưởng `streamlit` là script Node
  và báo lỗi cú pháp.
- **Phải trỏ vào `.venv/bin/streamlit`**, không dùng `streamlit` trần — PM2 không kích
  hoạt môi trường ảo, gọi tên trần sẽ chạy nhầm Python hệ thống (hoặc không tìm thấy).
- **Không bật `--watch`.** Ứng dụng ghi liên tục vào `data/app.db`, bật watch sẽ khiến
  PM2 khởi động lại vô tận.

Theo dõi:

```bash
pm2 logs debate
pm2 status
pm2 restart debate       # sau khi cập nhật mã nguồn
```

## 8. Mở cổng 8501

Có **hai tầng tường lửa** phải mở, thiếu tầng nào cũng không vào được — đây là lỗi hay
gặp nhất khi chạy thẳng theo IP.

**Tầng 1 — tường lửa trên máy chủ:**

```bash
sudo ufw allow OpenSSH
sudo ufw allow 8501/tcp
sudo ufw --force enable
sudo ufw status
```

**Tầng 2 — tường lửa của nhà cung cấp** (không nằm trong Ubuntu, phải mở trên trang
quản trị):

| Nhà cung cấp | Nơi cấu hình |
| --- | --- |
| AWS EC2 / Lightsail | Security Group → Inbound rules → Custom TCP 8501, Source `0.0.0.0/0` |
| Google Cloud | VPC network → Firewall → tạo rule `tcp:8501` |
| Azure | Network security group → Inbound security rules → port 8501 |
| DigitalOcean | Networking → Firewalls → Inbound Rules → TCP 8501 |
| VPS Việt Nam (Viettel, VNPT, Vinahost...) | Thường mở sẵn, không cần làm gì |

Kiểm tra từ máy của bạn:

```powershell
curl.exe -s -o NUL -w "%{http_code}`n" http://<IP máy chủ>:8501/
```

Ra `200` là xong. Truy cập `http://<IP máy chủ>:8501`.

## 9. (Tuỳ chọn) Bỏ `:8501` khỏi địa chỉ

Muốn người học chỉ cần gõ `http://<IP máy chủ>` thì cho Streamlit chạy thẳng cổng 80.
Tiến trình vẫn chạy dưới tài khoản `ubuntu`, chỉ được cấp thêm quyền gắn cổng thấp:

```bash
sudo nano /etc/systemd/system/debate.service
```

Sửa hai chỗ:

- `--server.port=8501` → `--server.port=80`
- bỏ dấu `#` ở dòng `AmbientCapabilities=CAP_NET_BIND_SERVICE`

Rồi áp dụng và mở cổng 80:

```bash
sudo systemctl daemon-reload && sudo systemctl restart debate
sudo ufw allow 80/tcp
```

Nhớ mở cổng 80 ở tường lửa nhà cung cấp nữa.

## 10. Bảo mật khi chạy HTTP trần

Token giữ phiên đăng nhập nằm trên URL (`?sid=...`). Chạy HTTP không mã hoá nghĩa là cả
token lẫn mật khẩu lúc đăng nhập đều đi qua mạng ở dạng rõ. Chấp nhận được khi dùng
trong mạng nội bộ trường/lớp hoặc lúc thử nghiệm, **không nên** để vậy nếu mở ra
Internet lâu dài.

Ba mức xử lý, chọn theo nhu cầu:

**a) Giảm thiệt hại (làm ngay, không tốn gì):** rút ngắn hạn phiên trong `.env`

```bash
SESSION_TTL_DAYS=1
```

**b) HTTPS không cần nginx** — Streamlit tự phục vụ TLS. Cần một cặp chứng chỉ; nếu chưa
có tên miền thì tạo chứng chỉ tự ký (trình duyệt sẽ cảnh báo, bấm bỏ qua là vào được):

```bash
mkdir -p /home/ubuntu/debate/certs && cd /home/ubuntu/debate/certs
openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
  -keyout key.pem -out cert.pem -subj "/CN=$(curl -s ifconfig.me)"
chmod 600 key.pem
```

Thêm hai cờ vào `ExecStart` trong `/etc/systemd/system/debate.service`:

```ini
    --server.sslCertFile=/home/ubuntu/debate/certs/cert.pem \
    --server.sslKeyFile=/home/ubuntu/debate/certs/key.pem
```

```bash
sudo systemctl daemon-reload && sudo systemctl restart debate
```

Truy cập bằng `https://<IP máy chủ>:8501`. Lưu ý tài liệu Streamlit ghi rõ tính năng SSL
này không dành cho môi trường tải cao; đủ dùng cho một lớp học.

**c) Chứng chỉ thật, không cảnh báo trình duyệt:** cần tên miền — xem phụ lục bên dưới.

## Vận hành

**Cập nhật mã nguồn:**

```powershell
# Trên Windows
rsync -avz -e "ssh -i $KEY" --exclude '.venv' --exclude '__pycache__' `
  --exclude '.env' --exclude 'data/app.db*' ./ ${SRV}:/home/ubuntu/debate/
```

```bash
# Trên máy chủ
cd /home/ubuntu/debate
.venv/bin/pip install -r requirements.txt     # nếu requirements đổi
.venv/bin/python bootstrap_data.py            # nếu thêm tài liệu

sudo systemctl restart debate                 # nếu chạy bằng systemd
pm2 restart debate                            # nếu chạy bằng PM2
```

**Sao lưu CSDL** (chứa tài khoản, lịch sử học, embedding). Đặt cron chạy hằng đêm:

```bash
mkdir -p /home/ubuntu/backups
crontab -e
```

Thêm dòng:

```cron
0 2 * * * sqlite3 /home/ubuntu/debate/data/app.db ".backup '/home/ubuntu/backups/app-$(date +\%F).db'" && find /home/ubuntu/backups -name 'app-*.db' -mtime +14 -delete
```

**Kiểm tra sức khoẻ hệ thống:**

```bash
sudo systemctl status debate
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8501/
.venv/bin/python -c "from core import rag; print(rag.stats())"
```

## Xử lý sự cố

| Hiện tượng | Nguyên nhân thường gặp | Cách xử lý |
| --- | --- | --- |
| Trình duyệt quay mãi rồi báo hết thời gian | Cổng 8501 chưa mở ở tường lửa nhà cung cấp | Xem lại **tầng 2** ở bước 8; kiểm tra trên máy chủ bằng `curl 127.0.0.1:8501` — nếu ra 200 thì lỗi chắc chắn ở tường lửa |
| Trên máy chủ `curl` cũng không được | Dịch vụ chưa chạy | `systemctl status debate` + `journalctl -u debate -n 50`, hoặc `pm2 status` + `pm2 logs debate --lines 50` |
| PM2 báo `SyntaxError: Invalid or unexpected token` | Thiếu `--interpreter none`, PM2 chạy `streamlit` bằng Node | `pm2 delete debate` rồi khởi động lại đúng cú pháp ở bước 7B |
| PM2 khởi động lại liên tục | Bật `--watch`, `data/app.db` thay đổi liên tục | `pm2 delete debate`, khởi động lại không kèm `--watch` |
| Chỉ vào được từ chính máy chủ | Dịch vụ đang gắn `127.0.0.1` | Đảm bảo `--server.address=0.0.0.0` trong file service, rồi `daemon-reload` + `restart` |
| Vào được nhưng phản biện báo lỗi gọi mô hình | Thiếu/sai `OPENAI_API_KEY`, hoặc hết hạn mức | `cat .env`, kiểm tra hạn mức tài khoản OpenAI |
| Ứng dụng chạy ở "chế độ ngoại tuyến" | `.env` không được đọc | `.env` phải nằm ngay tại `/home/ubuntu/debate/.env`, cùng cấp `app.py` |
| `sqlite3.OperationalError: attempt to write a readonly database` | Sai chủ sở hữu file | `sudo chown -R ubuntu:ubuntu /home/ubuntu/debate` |
| Chương môn Luật hiện "chưa có tài liệu" | Chưa chạy nạp dữ liệu | `.venv/bin/python bootstrap_data.py` |
| Đăng nhập xong tải lại trang là mất phiên | URL bị mất tham số `?sid=...` | Tải lại bằng F5 chứ đừng gõ lại địa chỉ tay |
| (Khi dùng nginx) trang trắng quay vòng mãi | Chưa chuyển tiếp WebSocket | Kiểm tra hai dòng `proxy_set_header Upgrade/Connection` |

## Quy mô và giới hạn

Ứng dụng chạy đơn tiến trình, dữ liệu trong SQLite ở chế độ WAL. Máy 1 vCPU / 1 GB RAM
đủ cho một lớp vài chục sinh viên dùng đồng thời — phần lớn thời gian là chờ OpenAI trả
lời chứ không phải tính toán tại chỗ. Muốn phục vụ quy mô lớn hơn thì phải tách CSDL ra
PostgreSQL và chạy nhiều tiến trình, lúc đó `core/db.py` và `core/rag.py` cần viết lại.

## Phụ lục — đặt nginx phía trước (tuỳ chọn)

Chỉ cần khi bạn có tên miền và muốn HTTPS hợp lệ bằng Let's Encrypt, hoặc muốn dùng
chung máy chủ cho nhiều ứng dụng.

```bash
sudo apt install -y nginx
sudo nano /etc/systemd/system/debate.service   # đổi --server.address=0.0.0.0 thành 127.0.0.1
sudo systemctl daemon-reload && sudo systemctl restart debate

sudo cp /home/ubuntu/debate/deploy/nginx-debate.conf /etc/nginx/sites-available/debate
sudo nano /etc/nginx/sites-available/debate    # đổi server_name thành tên miền thật
sudo ln -sf /etc/nginx/sites-available/debate /etc/nginx/sites-enabled/debate
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

sudo ufw delete allow 8501/tcp
sudo ufw allow 'Nginx Full'

sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d hocphanbien.example.edu.vn
```

File [nginx-debate.conf](nginx-debate.conf) đã có sẵn phần chuyển tiếp WebSocket
(`/_stcore/stream`) và giữ header `Host` — thiếu hai thứ này thì trang trắng quay vòng
mãi hoặc người dùng bị đăng xuất liên tục.
